import { eq, and, desc, count, sql } from "drizzle-orm";
import { db } from "@/db";
import { tribes, tribeMembers, tribeInvites, tribeBattles, tribeBattleScores, users, questions, notifications } from "@/db/schema";
import { uid, now, json, getSessionUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

type Ctx = { params: Promise<{ id: string }> };

async function tribeOr404(id: string) {
  const t = (await db.select().from(tribes).where(eq(tribes.id, id)).limit(1))[0];
  return t ?? null;
}

// GET ?action=members|battles — جزئیات قبیله
export async function GET(req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  const t = await tribeOr404(id);
  if (!t) return json({ error: "not-found" }, 404);
  const action = new URL(req.url).searchParams.get("action") || "detail";
  const me = await getSessionUser();

  if (action === "members") {
    const members = await db.select({ m: tribeMembers, u: users }).from(tribeMembers)
      .leftJoin(users, eq(users.id, tribeMembers.userId)).where(eq(tribeMembers.tribeId, id));
    return json(members.map((r) => ({ id: r.u?.id, name: r.u?.name, avatar: r.u?.avatar, xp: r.u?.xp, level: r.u?.level, wins: r.u?.wins, role: r.m.role, contributedXp: r.m.contributedXp, online: (r.u?.lastSeen ?? 0) > now() - 5 * 60000 })));
  }
  if (action === "battles") {
    const battles = await db.select().from(tribeBattles)
      .where(sql`${tribeBattles.tribeA} = ${id} OR ${tribeBattles.tribeB} = ${id}`)
      .orderBy(desc(tribeBattles.createdAt)).limit(20);
    return json(battles);
  }
  const c = await db.select({ c: count() }).from(tribeMembers).where(eq(tribeMembers.tribeId, id));
  const myMembership = me ? (await db.select().from(tribeMembers).where(and(eq(tribeMembers.tribeId, id), eq(tribeMembers.userId, me.id))).limit(1))[0] : null;
  return json({ ...t, memberCount: Number(c[0]?.c ?? 0), myRole: myMembership?.role ?? null, isMember: !!myMembership });
}

// POST ?action=join|leave|invite|invite-accept|challenge|battle-answer|update
export async function POST(req: Request, ctx: Ctx) {
  await ensureSeed();
  const { id } = await ctx.params;
  const action = new URL(req.url).searchParams.get("action") || "join";
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed", message: "ابتدا وارد بازی شو 🌱" }, 401);
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }

  // ---- عضویت ----
  if (action === "join") {
    const t = await tribeOr404(id);
    if (!t) return json({ error: "not-found" }, 404);
    const already = await db.select().from(tribeMembers).where(eq(tribeMembers.userId, me.id)).limit(1);
    if (already[0]) return json({ error: already[0].tribeId === id ? "قبلاً عضو این قبیله‌ای!" : "تو عضو یک قبیلهٔ دیگر هستی!" }, 400);
    const c = await db.select({ c: count() }).from(tribeMembers).where(eq(tribeMembers.tribeId, id));
    if (Number(c[0]?.c ?? 0) >= (t.maxMembers ?? 30)) return json({ error: "ظرفیت این قبیله پر است." }, 400);
    if (!t.isPublic) {
      const code = String(b.inviteCode || "");
      if (code.toUpperCase() !== (t.inviteCode || "").toUpperCase()) {
        // بررسی دعوت‌نامه
        const inv = await db.select().from(tribeInvites).where(and(eq(tribeInvites.tribeId, id), eq(tribeInvites.userId, me.id), eq(tribeInvites.status, "pending"))).limit(1);
        if (!inv[0]) return json({ error: "این قبیله خصوصی است؛ کد دعوت لازم است. 🔑" }, 403);
        await db.update(tribeInvites).set({ status: "accepted" }).where(eq(tribeInvites.id, inv[0].id));
      }
    }
    await db.insert(tribeMembers).values({ tribeId: id, userId: me.id, role: "member", contributedXp: 0, joinedAt: now() });
    return json({ ok: true, message: `به قبیلهٔ «${t.name}» خوش آمدی! 🎉` });
  }

  // ---- خروج ----
  if (action === "leave") {
    const membership = (await db.select().from(tribeMembers).where(and(eq(tribeMembers.tribeId, id), eq(tribeMembers.userId, me.id))).limit(1))[0];
    if (!membership) return json({ error: "عضو نیستی." }, 400);
    const t = await tribeOr404(id);
    if (membership.role === "owner") {
      // انتقال مالکیت به قدیمی‌ترین عضو یا حذف قبیله
      const others = await db.select().from(tribeMembers).where(eq(tribeMembers.tribeId, id));
      const next = others.filter((x) => x.userId !== me.id).sort((a, b2) => a.joinedAt - b2.joinedAt)[0];
      if (next) {
        await db.update(tribeMembers).set({ role: "owner" }).where(and(eq(tribeMembers.tribeId, id), eq(tribeMembers.userId, next.userId)));
        await db.update(tribes).set({ ownerId: next.userId }).where(eq(tribes.id, id));
      } else {
        await db.delete(tribes).where(eq(tribes.id, id));
      }
    }
    await db.delete(tribeMembers).where(and(eq(tribeMembers.tribeId, id), eq(tribeMembers.userId, me.id)));
    return json({ ok: true, message: t ? `از قبیلهٔ «${t.name}» خارج شدی.` : "قبیله حذف شد." });
  }

  // ---- دعوت ----
  if (action === "invite") {
    const membership = (await db.select().from(tribeMembers).where(and(eq(tribeMembers.tribeId, id), eq(tribeMembers.userId, me.id))).limit(1))[0];
    if (!membership) return json({ error: "اول باید عضو قبیله باشی." }, 403);
    const targetName = String(b.userName || "").trim();
    const targetId = String(b.userId || "").trim();
    let target = null;
    if (targetId) target = (await db.select().from(users).where(eq(users.id, targetId)).limit(1))[0];
    else if (targetName) target = (await db.select().from(users).where(eq(users.name, targetName)).limit(1))[0];
    if (!target) return json({ error: "بازیکن پیدا نشد. نام دقیق را بنویس." }, 404);
    const t = await tribeOr404(id);
    await db.insert(tribeInvites).values({ id: uid("inv"), tribeId: id, userId: target.id, inviterId: me.id, status: "pending", createdAt: now() });
    await db.insert(notifications).values({ id: uid("n"), userId: target.id, title: `🛡️ دعوت به قبیلهٔ «${t?.name}»`, body: `${me.name} تو را به قبیله دعوت کرد!`, link: "#tribes", createdAt: now(), seen: 0 });
    return json({ ok: true, message: `دعوت برای ${target.name} ارسال شد ✉️` });
  }

  // ---- چالش نبرد قبیله‌ای ----
  if (action === "challenge") {
    const myMem = (await db.select().from(tribeMembers).where(eq(tribeMembers.userId, me.id)).limit(1))[0];
    if (!myMem) return json({ error: "اول باید عضو یک قبیله باشی!" }, 400);
    const enemyId = id; // قبیلهٔ حریف از مسیر
    if (myMem.tribeId === enemyId) return json({ error: "نمی‌توانی با قبیلهٔ خودت بجنگی! 😄" }, 400);
    const enemy = await tribeOr404(enemyId);
    if (!enemy) return json({ error: "not-found" }, 404);
    const category = String(b.category || "general");
    // ۵ سؤال تصادفی از دسته
    const bank = await db.select().from(questions).where(eq(questions.category, category)).limit(50);
    const pool = bank.length >= 5 ? bank : await db.select().from(questions).limit(50);
    const shuffled = [...pool].sort(() => Math.random() - 0.5).slice(0, 5).map((q) => ({ id: q.id, category: q.category, title: q.title, options: q.options, correct: q.correct, explanation: q.explanation, seconds: q.seconds }));
    if (!shuffled.length) return json({ error: "بانک سؤال خالی است." }, 500);
    const battleId = uid("btl");
    const t = now();
    await db.insert(tribeBattles).values({
      id: battleId, tribeA: myMem.tribeId, tribeB: enemyId, category, status: "active",
      questions: shuffled, scoreA: 0, scoreB: 0, winnerId: "", createdBy: me.id,
      startsAt: t, endsAt: t + 48 * 3600000, createdAt: t,
    });
    // اطلاع به اعضای حریف (حداکثر ۲۰ نفر)
    const rivals = await db.select().from(tribeMembers).where(eq(tribeMembers.tribeId, enemyId)).limit(20);
    const myTribe = await tribeOr404(myMem.tribeId);
    for (const r of rivals) {
      try { await db.insert(notifications).values({ id: uid("n"), userId: r.userId, title: `⚔️ چالش نبرد از «${myTribe?.name}»!`, body: "قبیله‌تان به نبرد دعوت شده؛ وارد شوید و بجنگید!", link: "#tribes", createdAt: now(), seen: 0 }); } catch { /* ignore */ }
    }
    return json({ ok: true, battleId, message: "نبرد آغاز شد! ⚔️" });
  }

  // ---- ثبت نتیجهٔ نبرد ----
  if (action === "battle-answer") {
    const battleId = String(b.battleId || "");
    const battle = (await db.select().from(tribeBattles).where(eq(tribeBattles.id, battleId)).limit(1))[0];
    if (!battle || battle.status !== "active") return json({ error: "نبرد فعال نیست." }, 400);
    const myMem = (await db.select().from(tribeMembers).where(eq(tribeMembers.userId, me.id)).limit(1))[0];
    if (!myMem || (myMem.tribeId !== battle.tribeA && myMem.tribeId !== battle.tribeB)) return json({ error: "عضو این نبرد نیستی." }, 403);
    const score = Math.max(0, Math.min(5000, Number(b.score) || 0));
    const correct = Math.max(0, Math.min(10, Number(b.correct) || 0));
    await db.insert(tribeBattleScores).values({ battleId, userId: me.id, tribeId: myMem.tribeId, score, correct, answers: [], createdAt: now() }).onConflictDoNothing();
    // به‌روزرسانی امتیاز تجمیعی قبیله در نبرد
    if (myMem.tribeId === battle.tribeA) await db.update(tribeBattles).set({ scoreA: sql`${tribeBattles.scoreA} + ${score}` }).where(eq(tribeBattles.id, battleId));
    else await db.update(tribeBattles).set({ scoreB: sql`${tribeBattles.scoreB} + ${score}` }).where(eq(tribeBattles.id, battleId));
    // XP کاربر و قبیله
    await db.update(users).set({ xp: sql`${users.xp} + ${Math.round(score / 10)}`, played: sql`${users.played} + 1` }).where(eq(users.id, me.id));
    await db.update(tribes).set({ xp: sql`${tribes.xp} + ${Math.round(score / 10)}` }).where(eq(tribes.id, myMem.tribeId));
    await db.update(tribeMembers).set({ contributedXp: sql`${tribeMembers.contributedXp} + ${Math.round(score / 10)}` }).where(and(eq(tribeMembers.tribeId, myMem.tribeId), eq(tribeMembers.userId, me.id)));
    // پایان خودکار اگر هر دو طرف حداقل یک شرکت‌کننده داشتند و ۱۰ دقیقه گذشته؟ ساده: اگر مجموع شرکت‌کنندگان >= ۲ و اختلاف ثبت شد، خاتمه نده؛ مدیر/زمان خاتمه می‌دهد. اما اگر ۴۸ ساعت گذشته، ببند.
    const fresh = (await db.select().from(tribeBattles).where(eq(tribeBattles.id, battleId)).limit(1))[0];
    return json({ ok: true, battle: fresh });
  }

  // ---- ویرایش قبیله (مالک/ادمین) ----
  if (action === "update") {
    const membership = (await db.select().from(tribeMembers).where(and(eq(tribeMembers.tribeId, id), eq(tribeMembers.userId, me.id))).limit(1))[0];
    if (!membership || (membership.role !== "owner" && membership.role !== "admin" && me.role !== "admin")) return json({ error: "فقط مالک قبیله." }, 403);
    const patch: Record<string, unknown> = {};
    if (typeof b.description === "string") patch.description = (b.description as string).slice(0, 300);
    if (typeof b.motto === "string") patch.motto = (b.motto as string).slice(0, 120);
    if (typeof b.logoEmoji === "string") patch.logoEmoji = (b.logoEmoji as string).slice(0, 8);
    if (typeof b.logoColor === "string") patch.logoColor = (b.logoColor as string).slice(0, 20);
    if (typeof b.isPublic === "boolean") patch.isPublic = b.isPublic;
    if (typeof b.name === "string" && (b.name as string).trim().length >= 3) patch.name = (b.name as string).trim().slice(0, 30);
    await db.update(tribes).set(patch).where(eq(tribes.id, id));
    return json({ ok: true });
  }

  return json({ error: "unknown-action" }, 400);
}
