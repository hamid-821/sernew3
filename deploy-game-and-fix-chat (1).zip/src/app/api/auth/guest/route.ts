import { db } from "@/db";
import { users, orgMembers } from "@/db/schema";
import { uid, now, pub, createSession, setAuthCookie, json } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

// سازگار با server.cjs نسخه اصلی + پشتیبانی از org
export async function POST(req: Request) {
  await ensureSeed();
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const orgId = String(b.org ?? b.orgId ?? "");
  const id = uid("u");
  const row = {
    id, localId: id,
    name: String(b.name || "میهمان").slice(0, 40),
    avatar: (b.avatar as object) ?? { seed: 1 },
    bio: "", email: String(b.email || ""), phone: String(b.phone || ""),
    provider: String(b.provider || "guest"),
    googleSub: "", role: "player", orgId,
    xp: 0, coins: 50, cups: 0, streak: 0, wins: 0, played: 0, rating: 1000, weekXp: 0, level: 1,
    interests: Array.isArray(b.interests) ? (b.interests as string[]).slice(0, 20) : [],
    friends: [], isPrivate: false, banned: false, isDemo: false,
    lastSeen: now(), lastDaily: "", createdAt: now(), extra: {},
  };
  await db.insert(users).values(row);
  if (orgId) {
    try { await db.insert(orgMembers).values({ orgId, userId: id, status: "approved", joinedAt: now() }).onConflictDoNothing(); } catch { /* ignore */ }
  }
  const saved = (await db.select().from(users).then((r) => r.find((x) => x.id === id)))!;
  const { token } = await createSession(id);
  const res = json({ ...pub(saved), serverToken: token });
  return setAuthCookie(res, token);
}
