import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, tribeMembers, tribes, notifications } from "@/db/schema";
import { uid, now, json, getSessionUser, pub } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

/** مرکز پاداش: ماموریت‌های روزانه + چرخ شانس + تالار افتخار (همه سمت سرور، ضدتقلب) */

const PRIZES = [
  { label: "۱۰ سکه", icon: "🪙", coins: 10, xp: 0, w: 22 },
  { label: "۲۰ امتیاز", icon: "⭐", coins: 0, xp: 20, w: 20 },
  { label: "۲۵ سکه", icon: "🪙", coins: 25, xp: 0, w: 18 },
  { label: "۵۰ سکه", icon: "💰", coins: 50, xp: 0, w: 12 },
  { label: "۶۰ امتیاز", icon: "🌟", coins: 0, xp: 60, w: 12 },
  { label: "۱۰۰ سکه", icon: "💎", coins: 100, xp: 0, w: 8 },
  { label: "۱۵۰ امتیاز", icon: "🚀", coins: 0, xp: 150, w: 5 },
  { label: "۲۵۰ سکه ⚡", icon: "👑", coins: 250, xp: 0, w: 3 },
];

type Extra = {
  day?: string; base?: { played: number; xp: number; wins: number };
  claimed?: Record<string, boolean>; spunDay?: string; totalSpins?: number; lastPrize?: string;
};

const today = () => new Date().toISOString().slice(0, 10);

async function loadState(me: typeof users.$inferSelect) {
  const ex: Extra = { ...((me.extra as Extra) || {}) };
  const day = today();
  if (ex.day !== day || !ex.base) {
    ex.day = day;
    ex.base = { played: me.played ?? 0, xp: me.xp ?? 0, wins: me.wins ?? 0 };
    ex.claimed = {};
    await db.update(users).set({ extra: ex as Record<string, unknown> }).where(eq(users.id, me.id));
  }
  return ex;
}

async function buildQuests(me: typeof users.$inferSelect, ex: Extra) {
  const inTribe = (await db.select().from(tribeMembers).where(eq(tribeMembers.userId, me.id)).limit(1))[0];
  const b = ex.base!;
  const defs = [
    { id: "q-play", icon: "🎮", title: "۳ مسابقه انجام بده", target: 3, progress: (me.played ?? 0) - b.played, coins: 40, xp: 30 },
    { id: "q-xp", icon: "⭐", title: "۱۰۰ امتیاز تجربه بگیر", target: 100, progress: (me.xp ?? 0) - b.xp, coins: 50, xp: 20 },
    { id: "q-win", icon: "🏆", title: "یک مسابقه را ببر", target: 1, progress: (me.wins ?? 0) - b.wins, coins: 60, xp: 40 },
    { id: "q-daily", icon: "🎁", title: "جایزهٔ روزانه را بگیر", target: 1, progress: me.lastDaily === today() ? 1 : 0, coins: 20, xp: 10 },
    { id: "q-tribe", icon: "🛡️", title: "عضو یک قبیله باش", target: 1, progress: inTribe ? 1 : 0, coins: 30, xp: 30 },
  ];
  return defs.map((d) => {
    const progress = Math.max(0, Math.min(d.target, d.progress));
    return { ...d, progress, ready: progress >= d.target, claimed: !!ex.claimed?.[d.id] };
  });
}

export async function GET() {
  await ensureSeed();
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed", message: "ابتدا وارد بازی شو 🌱" }, 401);
  const ex = await loadState(me);
  const quests = await buildQuests(me, ex);
  const top = await db.select().from(users).orderBy(desc(users.weekXp)).limit(5);
  const better = await db.select({ c: sql<number>`count(*)` }).from(users).where(sql`${users.xp} > ${me.xp ?? 0}`);
  const topTribes = await db.select().from(tribes).orderBy(desc(tribes.xp)).limit(3);
  const xp = me.xp ?? 0;
  const level = Math.floor(xp / 250) + 1;
  return json({
    me: pub(me),
    level: { level, xp, into: xp % 250, need: 250 },
    rank: Number(better[0]?.c ?? 0) + 1,
    wheel: { canSpin: ex.spunDay !== today(), prizes: PRIZES.map(({ label, icon }) => ({ label, icon })), lastPrize: ex.lastPrize || "" },
    quests,
    hall: top.map((u, i) => ({ rank: i + 1, id: u.id, name: u.name, avatar: u.avatar, weekXp: u.weekXp, xp: u.xp })),
    tribes: topTribes.map((t) => ({ id: t.id, name: t.name, emoji: t.logoEmoji, xp: t.xp })),
  });
}

export async function POST(req: Request) {
  await ensureSeed();
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed", message: "ابتدا وارد بازی شو 🌱" }, 401);
  const url = new URL(req.url);
  const action = url.searchParams.get("action") || "";
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const ex = await loadState(me);

  if (action === "spin") {
    if (ex.spunDay === today()) return json({ error: "چرخ امروز را چرخاندی! فردا دوباره بیا 🎡" }, 400);
    const total = PRIZES.reduce((s, p) => s + p.w, 0);
    let r = Math.random() * total, index = 0;
    for (let i = 0; i < PRIZES.length; i++) { r -= PRIZES[i].w; if (r <= 0) { index = i; break; } }
    const p = PRIZES[index];
    ex.spunDay = today(); ex.totalSpins = (ex.totalSpins ?? 0) + 1; ex.lastPrize = p.label;
    await db.update(users).set({
      coins: sql`${users.coins} + ${p.coins}`, xp: sql`${users.xp} + ${p.xp}`, weekXp: sql`${users.weekXp} + ${p.xp}`,
      extra: ex as Record<string, unknown>,
    }).where(eq(users.id, me.id));
    return json({ ok: true, index, prize: { label: p.label, icon: p.icon, coins: p.coins, xp: p.xp } });
  }

  if (action === "claim") {
    const id = String(b.id || "");
    const q = (await buildQuests(me, ex)).find((x) => x.id === id);
    if (!q) return json({ error: "ماموریت پیدا نشد." }, 404);
    if (q.claimed) return json({ error: "این جایزه را قبلاً گرفتی ✅" }, 400);
    if (!q.ready) return json({ error: "هنوز ماموریت کامل نشده 💪" }, 400);
    ex.claimed = { ...(ex.claimed || {}), [id]: true };
    await db.update(users).set({
      coins: sql`${users.coins} + ${q.coins}`, xp: sql`${users.xp} + ${q.xp}`, weekXp: sql`${users.weekXp} + ${q.xp}`,
      extra: ex as Record<string, unknown>,
    }).where(eq(users.id, me.id));
    try {
      await db.insert(notifications).values({ id: uid("n"), userId: me.id, title: "✅ ماموریت کامل شد", body: `${q.title} — +${q.coins} سکه، +${q.xp} امتیاز`, link: "", createdAt: now(), seen: 1 });
    } catch { /* ignore */ }
    return json({ ok: true, coins: q.coins, xp: q.xp });
  }
  return json({ error: "action نامعتبر" }, 400);
}
