import { eq, desc, and } from "drizzle-orm";
import { db } from "@/db";
import { tournaments, tournamentPlayers, questions } from "@/db/schema";
import { uid, now, json, getSessionUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

// GET: فهرست تورنمنت‌ها (با وضعیت باز بودن بر اساس org کاربر)
export async function GET() {
  await ensureSeed();
  const me = await getSessionUser();
  const rows = await db.select().from(tournaments).orderBy(desc(tournaments.startsAt)).limit(40);
  const out = [];
  for (const t of rows) {
    const open = !!t.active && t.startsAt <= now() && t.endsAt >= now();
    const orgLocked = !!t.orgId && me?.orgId !== t.orgId;
    let joined = false, myScore = 0;
    if (me) {
      const p = await db.select().from(tournamentPlayers).where(and(eq(tournamentPlayers.tournamentId, t.id), eq(tournamentPlayers.userId, me.id))).limit(1);
      if (p[0]) { joined = true; myScore = p[0].score ?? 0; }
    }
    out.push({ ...t, open, orgLocked, joined, myScore, questions: undefined, questionCount: Array.isArray(t.questions) ? t.questions.length : 0 });
  }
  return json(out);
}

// POST ?action=create|join|submit — ساخت تورنمنت (کاربران هم می‌توانند!)، عضویت، ثبت نتیجه
export async function POST(req: Request) {
  await ensureSeed();
  const action = new URL(req.url).searchParams.get("action") || "join";
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed", message: "ابتدا وارد بازی شو 🌱" }, 401);
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }

  if (action === "create") {
    const title = String(b.title || "").trim().slice(0, 60);
    if (title.length < 4) return json({ error: "عنوان تورنمنت باید دست‌کم ۴ حرف باشد." }, 400);
    const category = String(b.category || "general");
    const days = Math.min(30, Math.max(1, Number(b.days) || 7));
    const bank = await db.select().from(questions).where(eq(questions.category, category)).limit(50);
    const pool = (bank.length >= 5 ? bank : await db.select().from(questions).limit(50)).sort(() => Math.random() - 0.5).slice(0, 8)
      .map((q) => ({ id: q.id, category: q.category, title: q.title, options: q.options, correct: q.correct, explanation: q.explanation, seconds: q.seconds }));
    const id = uid("tour");
    const t = now();
    await db.insert(tournaments).values({
      id, title, category, startsAt: t, endsAt: t + days * 86400000,
      description: String(b.description || "").slice(0, 300),
      orgId: String(b.orgId || ""), tribeOnly: !!b.tribeOnly,
      maxPlayers: 1000, questions: pool, active: true, createdBy: me.id, createdAt: t,
    });
    return json({ ok: true, id, message: "تورنمنت ساخته شد! 🏆" });
  }

  if (action === "join") {
    const id = String(b.id || b.tournamentId || "");
    const t = (await db.select().from(tournaments).where(eq(tournaments.id, id)).limit(1))[0];
    if (!t) return json({ error: "not-found" }, 404);
    if (t.orgId && me.orgId !== t.orgId) return json({ error: `این تورنمنت ویژهٔ سازمان دیگری است. 🏢` }, 403);
    await db.insert(tournamentPlayers).values({ tournamentId: id, userId: me.id, score: 0, rank: 0, joinedAt: now() }).onConflictDoNothing();
    return json({ ok: true, questions: t.questions });
  }

  if (action === "submit") {
    const id = String(b.id || b.tournamentId || "");
    const score = Math.max(0, Math.min(10000, Number(b.score) || 0));
    const p = (await db.select().from(tournamentPlayers).where(and(eq(tournamentPlayers.tournamentId, id), eq(tournamentPlayers.userId, me.id))).limit(1))[0];
    if (!p) return json({ error: "اول باید عضو شوی." }, 400);
    if (score > (p.score ?? 0)) {
      await db.update(tournamentPlayers).set({ score }).where(and(eq(tournamentPlayers.tournamentId, id), eq(tournamentPlayers.userId, me.id)));
    }
    return json({ ok: true });
  }

  return json({ error: "unknown-action" }, 400);
}
