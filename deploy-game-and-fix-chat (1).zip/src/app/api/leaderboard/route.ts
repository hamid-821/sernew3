import { desc } from "drizzle-orm";
import { db } from "@/db";
import { users, tribes, tribeMembers } from "@/db/schema";
import { json, pub } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";
import { count, eq } from "drizzle-orm";

// ?scope=players|tribes|week
export async function GET(req: Request) {
  await ensureSeed();
  const scope = new URL(req.url).searchParams.get("scope") || "players";
  if (scope === "tribes") {
    const rows = await db.select().from(tribes).orderBy(desc(tribes.xp)).limit(50);
    const out = [];
    for (const [i, t] of rows.entries()) {
      const c = await db.select({ c: count() }).from(tribeMembers).where(eq(tribeMembers.tribeId, t.id));
      out.push({ rank: i + 1, ...t, memberCount: Number(c[0]?.c ?? 0) });
    }
    return json(out);
  }
  if (scope === "week") {
    const rows = await db.select().from(users).orderBy(desc(users.weekXp)).limit(50);
    return json(rows.map((u, i) => ({ rank: i + 1, ...pub(u) })));
  }
  const rows = await db.select().from(users).orderBy(desc(users.xp)).limit(50);
  return json(rows.map((u, i) => ({ rank: i + 1, ...pub(u) })));
}
