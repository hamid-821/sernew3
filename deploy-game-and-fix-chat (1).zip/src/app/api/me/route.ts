import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { pub, json, getSessionUser, now } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

export async function GET() {
  await ensureSeed();
  const u = await getSessionUser();
  if (!u) return json({ error: "not-authed" }, 401);
  return json(pub(u));
}

export async function POST(req: Request) {
  await ensureSeed();
  const u = await getSessionUser();
  if (!u) return json({ error: "not-authed" }, 401);
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const patch: Record<string, unknown> = { lastSeen: now() };
  for (const k of ["xp", "coins", "cups", "streak", "wins", "played", "rating", "weekXp"]) {
    if (typeof b[k] === "number") patch[k === "weekXp" ? "weekXp" : k] = Math.max(0, Math.round(b[k] as number));
  }
  if (typeof b.name === "string" && (b.name as string).trim()) patch.name = (b.name as string).trim().slice(0, 40);
  if (b.avatar !== undefined) patch.avatar = b.avatar;
  if (Array.isArray(b.interests)) patch.interests = (b.interests as string[]).slice(0, 20);
  if (typeof b.bio === "string") patch.bio = (b.bio as string).slice(0, 300);
  if (typeof b.org === "string" || typeof b.orgId === "string") patch.orgId = String(b.org ?? b.orgId).slice(0, 40);
  if (typeof patch.xp === "number") patch.level = Math.floor((patch.xp as number) / 250) + 1;
  await db.update(users).set(patch).where(eq(users.id, u.id));
  const rows = await db.select().from(users).where(eq(users.id, u.id)).limit(1);
  return json(pub(rows[0]));
}
