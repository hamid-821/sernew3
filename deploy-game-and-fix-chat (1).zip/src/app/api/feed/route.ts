import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { posts, stories } from "@/db/schema";
import { uid, now, json, getSessionUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/ensure-seed";

// GET ?type=posts|stories — فید سرور (بکاپ + نمایش)
// POST ?type=post|story — ثبت در سرور (آینهٔ localStorage) برای صف تأیید مدیر
export async function GET(req: Request) {
  await ensureSeed();
  const type = new URL(req.url).searchParams.get("type") || "posts";
  if (type === "stories") {
    const rows = await db.select().from(stories).orderBy(desc(stories.createdAt)).limit(60);
    return json(rows);
  }
  const rows = await db.select().from(posts).orderBy(desc(posts.createdAt)).limit(60);
  return json(rows);
}

export async function POST(req: Request) {
  await ensureSeed();
  const me = await getSessionUser();
  if (!me) return json({ error: "not-authed" }, 401);
  const type = new URL(req.url).searchParams.get("type") || "post";
  let b: Record<string, unknown> = {};
  try { b = await req.json(); } catch { b = {}; }
  const t = now();

  if (type === "story") {
    const title = String(b.title || "").slice(0, 500);
    if (title.length < 5) return json({ error: "متن سؤال کوتاه است." }, 400);
    const id = String(b.id || uid("st"));
    await db.insert(stories).values({
      id, userId: me.id, userName: me.name,
      category: String(b.category || "general"),
      title, options: Array.isArray(b.options) ? (b.options as string[]).slice(0, 4) : [],
      correct: Number(b.correct) || 0,
      explanation: String(b.explanation || "").slice(0, 1000),
      media: String(b.media || ""),
      status: me.role === "admin" ? "approved" : "pending",
      autoApproved: false, moderatedBy: "", createdAt: t, expiresAt: t + 86400000,
    }).onConflictDoNothing();
    return json({ ok: true, id, status: me.role === "admin" ? "approved" : "pending" });
  }

  const body = String(b.body || "").slice(0, 4000);
  if (body.length < 3) return json({ error: "متن پست کوتاه است." }, 400);
  const id = String(b.id || uid("post"));
  await db.insert(posts).values({
    id, userId: me.id, userName: me.name,
    category: String(b.category || "work"),
    body, media: String(b.media || ""), audio: String(b.audio || ""),
    status: me.role === "admin" ? "approved" : "pending",
    likes: 0, autoApproved: false, moderatedBy: "", moderatedAt: 0, createdAt: t,
  }).onConflictDoNothing();
  return json({ ok: true, id, status: me.role === "admin" ? "approved" : "pending" });
}
