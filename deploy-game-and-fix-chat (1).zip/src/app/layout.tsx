import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "گیمیفای ۲ | یک بازی، هزار تجربه",
  description: "گیمیفای ۲؛ رقابت کن، تجربه بساز و هر روز چیز تازه‌ای یاد بگیر. بازی پرسش و پاسخ و دانشگاه تجربه‌های عملی.",
};

export const viewport: Viewport = {
  themeColor: "#17111f",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
