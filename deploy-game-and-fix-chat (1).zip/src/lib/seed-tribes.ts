import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, tribes, tribeMembers, orgMembers, settings, tribeBattles } from "@/db/schema";
import { now } from "./auth";

/** ۶ قبیلهٔ نمونه با محوریت برق؛ هر کدام ۱۰ عضو (بازیکنان نمونه‌اند و با isDemo علامت خورده‌اند) */
const TRIBES = [
  { id: "tribe-sd-1", name: "صاعقه‌ها", tag: "صاعقه", emoji: "⚡", color: "#f8c56c", motto: "سریع‌تر از رعد، دقیق‌تر از ولت‌متر!", description: "تیم رقابتی شبکهٔ انتقال؛ عاشقان سؤال‌های سخت برق." },
  { id: "tribe-sd-2", name: "مدار بسته", tag: "مدار", emoji: "🔌", color: "#76bfec", motto: "جریان ما هیچ‌وقت قطع نمی‌شود.", description: "قبیلهٔ مهندسان مدار و الکترونیک قدرت." },
  { id: "tribe-sd-3", name: "پست‌های فشار قوی", tag: "HV", emoji: "🏭", color: "#a98cf7", motto: "۴۰۰ کیلوولت اراده!", description: "اپراتورها و تعمیرکاران پست‌های ۶۳ تا ۴۰۰ کیلوولت." },
  { id: "tribe-sd-4", name: "روشن‌دلان", tag: "نور", emoji: "💡", color: "#f2ca7c", motto: "هر جا تاریکی هست، ما می‌رسیم.", description: "تیم توزیع و روشنایی؛ خط‌به‌خط تا خانهٔ مردم." },
  { id: "tribe-sd-5", name: "انرژی سبز", tag: "سبز", emoji: "🌞", color: "#8cc993", motto: "خورشید، باد و آینده.", description: "علاقه‌مندان انرژی‌های تجدیدپذیر و نیروگاه خورشیدی." },
  { id: "tribe-sd-6", name: "ارت و ایمنی", tag: "ایمن", emoji: "🦺", color: "#eda0b9", motto: "اول ایمنی، بعد برق!", description: "نگهبانان ایمنی برق؛ ارتینگ، قفل‌گذاری و تگ‌اوت." },
];

const NAMES = [
  "رضا برق‌دار", "مینا ولتاژی", "علی ترانس", "سارا آمپر", "حسین مدار", "نگین فاز", "امیر کابل", "الهام ژنراتور", "کیان رله", "مهسا فیوز",
  "پارسا سیم‌بان", "ندا خازن", "بهرام سکسیونر", "یاسمن اهم", "آرش شبکه", "ترانه پست", "سهیل بریکر", "هانیه القا", "فرهاد توزیع", "شیدا هرتز",
  "مهدی روشنایی", "زهرا کلید", "امید ارت", "ستاره باتری", "داریوش نیرو", "آزاده پنل", "کامران تابلو", "لیلا مگر", "وحید کنتور", "رها سیم‌پیچ",
  "بابک اینورتر", "مریم دیژنکتور", "سعید فشارقوی", "الناز استارتر", "جواد کلیدزن", "نرگس مولد", "ایمان توربین", "پریسا سلول", "میلاد مقره", "فاطمه شین",
  "کوروش خط", "آیدا پاور", "رامین ولت", "غزل هادی", "شایان ثانویه", "مهتاب اولیه", "نیما سنسور", "سپیده فرکانس", "پوریا حفاظت", "دنا جرقه",
  "سینا برقکار", "ماهان اسکادا", "روژین انرژی", "تینا چراغ", "آرمان رله‌بان", "درسا خورشید", "کسری باد", "آیلین سیم", "فرزاد نیروگاه", "بیتا تپ‌چنجر",
];

export async function seedTribes() {
  const flag = await db.select().from(settings).where(eq(settings.key, "seed-tribes-v1")).limit(1);
  if (flag[0]) return;
  const t = now();
  const day = 86400000;
  let n = 0;
  for (let ti = 0; ti < TRIBES.length; ti++) {
    const T = TRIBES[ti];
    const ids: string[] = [];
    for (let k = 0; k < 10; k++) {
      const name = NAMES[n % NAMES.length];
      const uidv = `u-sd-${ti + 1}-${k + 1}`;
      const xp = Math.round(4200 - ti * 220 - k * 310 + ((n * 37) % 180));
      ids.push(uidv);
      await db.insert(users).values({
        id: uidv, localId: uidv, name, avatar: (n % 10) as unknown as object, bio: `عضو قبیلهٔ «${T.name}» ⚡`,
        provider: "demo", role: "player", orgId: "barq",
        xp: Math.max(150, xp), coins: 120 + ((n * 17) % 300), cups: (n * 3) % 14, streak: (n * 5) % 12,
        wins: 8 + ((n * 7) % 40), played: 24 + ((n * 11) % 80), rating: 1000 + ((n * 13) % 400),
        weekXp: 40 + ((n * 29) % 600), level: Math.floor(Math.max(150, xp) / 250) + 1,
        interests: ["electric", "safety"], friends: [], isPrivate: false, banned: false, isDemo: true,
        lastSeen: t - day * 2, lastDaily: "", createdAt: t - day * (3 + (n % 20)), extra: {},
      }).onConflictDoNothing();
      await db.insert(orgMembers).values({ orgId: "barq", userId: uidv, status: "approved", joinedAt: t }).onConflictDoNothing();
      n++;
    }
    const txp = ids.length * (2200 - ti * 180);
    await db.insert(tribes).values({
      id: T.id, name: T.name, tag: T.tag, description: T.description, motto: T.motto,
      logoEmoji: T.emoji, logoColor: T.color, ownerId: ids[0], maxMembers: 30,
      wins: 14 - ti * 2, losses: 3 + ti, xp: txp, rating: 1500 - ti * 60,
      isPublic: true, inviteCode: `BARQ${ti + 1}X`, createdAt: t - day * (20 - ti),
    }).onConflictDoNothing();
    for (let k = 0; k < ids.length; k++) {
      await db.insert(tribeMembers).values({
        tribeId: T.id, userId: ids[k], role: k === 0 ? "owner" : k === 1 ? "admin" : "member",
        contributedXp: Math.round(txp / ids.length) - k * 80, joinedAt: t - day * (10 - (k % 7)),
      }).onConflictDoNothing();
    }
  }
  // چند نبرد پایان‌یافتهٔ نمونه برای زنده‌بودن تاریخچه
  const pairs = [[0, 1], [2, 3], [4, 5], [0, 2]];
  for (let i = 0; i < pairs.length; i++) {
    const [a, b] = pairs[i];
    await db.insert(tribeBattles).values({
      id: `battle-sd-${i + 1}`, tribeA: TRIBES[a].id, tribeB: TRIBES[b].id, category: "electric", status: "finished",
      questions: [], scoreA: 620 - i * 40, scoreB: 480 + i * 25, winnerId: TRIBES[a].id, createdBy: "system",
      startsAt: t - day * (5 - i), endsAt: t - day * (4 - i), createdAt: t - day * (5 - i),
    }).onConflictDoNothing();
  }
  await db.insert(settings).values({ key: "seed-tribes-v1", value: JSON.stringify({ at: t }) }).onConflictDoNothing();
}
