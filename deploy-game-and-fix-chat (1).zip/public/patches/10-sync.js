/* 🔄 ذخیرهٔ دوگانه: مرورگر (دست‌نخورده) + سرور (Postgres) هم‌زمان
   - پروفایل localStorage با کلید gamify2-store-v2 دقیقاً سر جایش می‌ماند
   - همین پروفایل در سرور هم ذخیره می‌شود تا مدیر همهٔ کاربران را ببیند و کاربران واقعی به هم وصل شوند
   - بازیکنان واقعی سرور وارد فهرست بازیکنان بازی می‌شوند و چت واقعی (P2P) از همان رابط خود بازی کار می‌کند */
(function () {
  "use strict";
  if (window.__gamifySync) return;
  window.__gamifySync = true;

  var LS_KEY = "gamify2-store-v2";
  var META_KEY = "gamify2-server";
  var realIds = new Set();
  var myServerId = null;
  var syncing = false;
  var lastSyncAt = 0;

  // توکن نشست سرور: علاوه بر کوکی، در localStorage هم نگه داشته می‌شود و روی هر درخواست /api فرستاده می‌شود
  // (جلوگیری از خطای «ابتدا وارد شو» وقتی کوکی مرورگر ذخیره/ارسال نشود)
  try {
    var _origFetch = window.fetch;
    window.fetch = function (input, init) {
      try {
        var url = typeof input === "string" ? input : (input && input.url) || "";
        if (url.indexOf("/api/") === 0 || url.indexOf(location.origin + "/api/") === 0) {
          var tok = (JSON.parse(localStorage.getItem("gamify2-server") || "{}") || {}).token;
          if (tok) {
            init = init || {};
            var h = new Headers(init.headers || (typeof input !== "string" && input.headers) || {});
            if (!h.has("x-gamify-token")) h.set("x-gamify-token", tok);
            init.headers = h;
          }
        }
      } catch (e) {}
      return _origFetch.call(this, input, init);
    };
  } catch (e) {}

  function readStore() {
    try {
      var raw = localStorage.getItem(LS_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }
  function writeStore(s) {
    try { localStorage.setItem(LS_KEY, JSON.stringify(s)); } catch (e) {}
  }
  function readMeta() {
    try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch (e) { return {}; }
  }
  function writeMeta(m) {
    try { localStorage.setItem(META_KEY, JSON.stringify(m)); } catch (e) {}
  }

  function toast(msg) {
    try {
      if (typeof window.__gamifyToast === "function") return window.__gamifyToast(msg);
      var d = document.createElement("div");
      d.textContent = msg;
      d.style.cssText = "position:fixed;bottom:86px;right:16px;z-index:99999;background:#241a33;color:#fff;padding:10px 16px;border-radius:14px;font-size:13px;box-shadow:0 8px 30px rgba(0,0,0,.4);border:1px solid #a98cf7;font-family:Vazirmatn,sans-serif;";
      document.body.appendChild(d);
      setTimeout(function () { d.style.transition = "opacity .4s"; d.style.opacity = "0"; setTimeout(function(){ d.remove(); }, 450); }, 2600);
    } catch (e) {}
  }

  // ---- همگام‌سازی پروفایل به سرور ----
  function syncProfile(reason) {
    var store = readStore();
    if (!store || !store.profile) return Promise.resolve(null);
    if (syncing) return Promise.resolve(null);
    // حداقل هر ۱۵ ثانیه
    if (reason === "auto" && Date.now() - lastSyncAt < 15000) return Promise.resolve(null);
    syncing = true;
    var profile = store.profile;
    // org ممکن است در profile.org یا META باشد
    try {
      var meta = readMeta();
      if (!profile.org && meta.orgId) profile.org = meta.orgId;
    } catch (e) {}
    return fetch("/api/sync", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ profile: profile })
    }).then(function (r) { return r.json(); }).then(function (sv) {
      syncing = false;
      if (!sv || sv.error) return null;
      lastSyncAt = Date.now();
      myServerId = sv.id;
      var meta2 = readMeta();
      meta2.serverId = sv.id;
      if (sv.serverToken) meta2.token = sv.serverToken;
      meta2.syncedAt = Date.now();
      meta2.orgId = sv.orgId || profile.org || meta2.orgId || "";
      writeMeta(meta2);
      // اگر سرور جلوتر است (مثلاً از قبیله/دستگاه دیگر XP گرفته)، localStorage را هم بالا ببر (max)
      try {
        var st = readStore();
        if (st && st.profile) {
          var changed = false;
          ["xp", "coins", "cups", "streak", "wins", "played", "rating"].forEach(function (k) {
            if (typeof sv[k] === "number" && sv[k] > (st.profile[k] || 0)) { st.profile[k] = sv[k]; changed = true; }
          });
          if (sv.orgId && !st.profile.org) { st.profile.org = sv.orgId; changed = true; }
          if (changed) writeStore(st);
        }
      } catch (e) {}
      try { window.dispatchEvent(new CustomEvent("gamify:synced", { detail: sv })); } catch (e) {}
      return sv;
    }).catch(function () { syncing = false; return null; });
  }

  // ---- آینه‌کردن پست/استوری به سرور برای صف تأیید مدیر ----
  var mirroredPosts = {};
  var mirroredStories = {};
  try {
    var mm = readMeta();
    mirroredPosts = mm.mirroredPosts || {};
    mirroredStories = mm.mirroredStories || {};
  } catch (e) {}
  function saveMirrored() {
    try { var m = readMeta(); m.mirroredPosts = mirroredPosts; m.mirroredStories = mirroredStories; writeMeta(m); } catch (e) {}
  }
  function mirrorContent() {
    if (!myServerId && !readMeta().serverId) return;
    var store = readStore();
    if (!store || !store.profile) return;
    var myId = store.profile.id;
    // پست‌های خودم که هنوز آینه نشده
    (store.posts || []).filter(function (p) { return p && (p.authorId === myId) && !mirroredPosts[p.id]; }).slice(0, 5).forEach(function (p) {
      mirroredPosts[p.id] = 1;
      fetch("/api/feed?type=post", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ id: String(p.id).slice(0, 60), category: p.category || "work", body: p.body || "", media: typeof p.media === "string" ? p.media : "" }) }).catch(function(){});
    });
    (store.stories || []).filter(function (s) { return s && (s.authorId === myId) && !mirroredStories[s.id]; }).slice(0, 5).forEach(function (s) {
      mirroredStories[s.id] = 1;
      fetch("/api/feed?type=story", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ id: String(s.id).slice(0, 60), category: s.category || "general", title: s.title || s.body || "", options: s.options || [], correct: s.correct || 0, explanation: s.explanation || "", media: typeof s.media === "string" ? s.media : "" }) }).catch(function(){});
    });
    saveMirrored();
  }

  // ---- ادغام بازیکنان واقعی سرور در فهرست بازیکنان بازی ----
  function mergeRealPlayers(serverPlayers) {
    try {
      var store = readStore();
      if (!store) return;
      var local = store.players || [];
      var byId = {};
      local.forEach(function (p) { byId[p.id] = p; });
      var added = 0;
      serverPlayers.forEach(function (sp, i) {
        if (!sp || !sp.id) return;
        if (sp.id === myServerId) return; // خودم
        realIds.add(sp.id);
        if (byId[sp.id]) {
          // به‌روزرسانی آمار
          var lp = byId[sp.id];
          lp.xp = sp.xp || lp.xp; lp.coins = sp.coins || lp.coins; lp.cups = sp.cups || lp.cups;
          lp.wins = sp.wins || lp.wins; lp.played = sp.played || lp.played;
          lp.name = sp.name || lp.name; lp.online = !!sp.online; lp.lastSeen = sp.lastSeen;
          return;
        }
        local.push({
          id: sp.id, name: sp.name || "بازیکن", avatar: sp.avatar || { seed: (i % 10) + 1 },
          bio: sp.bio || "بازیکن واقعی گیمیفای ⚡", xp: sp.xp || 0, coins: sp.coins || 50,
          cups: sp.cups || 0, rating: sp.rating || 1000, wins: sp.wins || 0, played: sp.played || 0,
          weekXp: sp.weekXp || 0, org: sp.orgId || "", publicVisible: true, chatPrivacy: "all",
          kind: "real", accuracy: 0.7, banned: false, lastSeen: sp.lastSeen || Date.now(),
          isReal: true, online: !!sp.online
        });
        added++;
      });
      if (added > 0) {
        // سقف: حداکثر ۳۰۰ بازیکن محلی نگه دار (بوت‌ها + واقعی‌ها)
        if (local.length > 400) {
          var bots = local.filter(function (p) { return p.kind !== "real"; }).slice(0, 200);
          var reals = local.filter(function (p) { return p.kind === "real"; }).slice(0, 200);
          local = bots.concat(reals);
        }
        store.players = local;
        writeStore(store);
      }
      try { window.dispatchEvent(new CustomEvent("gamify:players", { detail: { count: serverPlayers.length } })); } catch (e) {}
    } catch (e) {}
  }

  function fetchRealPlayers() {
    if (!readStore() || !readStore().profile) return;
    fetch("/api/players?limit=120", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
      if (Array.isArray(rows)) mergeRealPlayers(rows);
    }).catch(function () {});
  }

  // ---- چت واقعی P2P از داخل رابط خود بازی ----
  var sentToServer = {};
  try { sentToServer = readMeta().sentToServer || {}; } catch (e) {}
  function pumpOutgoingDMs() {
    if (!myServerId) return;
    var store = readStore();
    if (!store || !store.messages) return;
    var mine = store.messages.filter(function (m) { return m && m.from === "me" && realIds.has(m.thread) && !sentToServer[m.id]; }).slice(0, 5);
    if (!mine.length) return;
    mine.forEach(function (m) {
      sentToServer[m.id] = 1;
      fetch("/api/messages", { method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ to: m.thread, text: m.text || "" }) }).catch(function () { delete sentToServer[m.id]; });
    });
    try { var mt = readMeta(); mt.sentToServer = sentToServer; writeMeta(mt); } catch (e) {}
  }

  var lastDmCheck = 0;
  var knownServerMsg = {};
  try { knownServerMsg = readMeta().knownServerMsg || {}; } catch (e) {}
  function pumpIncomingDMs() {
    if (!myServerId) return;
    if (Date.now() - lastDmCheck < 20000) return;
    lastDmCheck = Date.now();
    var store = readStore();
    if (!store) return;
    // مخاطب‌های واقعی من = threadهایی که real هستند + خودم
    var threads = {};
    (store.messages || []).forEach(function (m) { if (m && realIds.has(m.thread)) threads[m.thread] = 1; });
    // حداقل: اگر کسی به من پیام داده ولی thread ندارم، از سرور نمی‌دانم — پس هر ۶۰ ثانیه همهٔ آنلاین‌ها را چک نکن؛
    // به‌جاش: اگر اعلان جدید داریم، thread را می‌سازیم (در بخش اعلان‌ها)
    Object.keys(threads).slice(0, 6).forEach(function (tid, idx) {
      setTimeout(function () {
        fetch("/api/messages?with=" + encodeURIComponent(tid), { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
          if (!Array.isArray(rows) || !rows.length) return;
          var st = readStore();
          if (!st) return;
          var fresh = 0;
          rows.forEach(function (sm) {
            var key = "srv-" + sm.id;
            if (knownServerMsg[key]) return;
            knownServerMsg[key] = 1;
            // آیا از قبل در local هست؟ (بر اساس id یا متن+زمان نزدیک)
            var exists = (st.messages || []).some(function (lm) { return lm.id === key || (lm.text === sm.text && Math.abs((lm.at || 0) - sm.at) < 5000); });
            if (exists) return;
            st.messages = st.messages || [];
            st.messages.push({
              id: key, thread: sm.from_id === myServerId ? sm.to_id : sm.from_id,
              from: sm.from_id === myServerId ? "me" : "them",
              text: sm.text, at: sm.at, read: sm.from_id === myServerId ? true : false, real: true
            });
            if (sm.from_id !== myServerId) fresh++;
          });
          if (fresh > 0) {
            writeStore(st);
            try { var mt = readMeta(); mt.knownServerMsg = knownServerMsg; writeMeta(mt); } catch (e) {}
            toast("📩 " + fresh + " پیام واقعی جدید داری! (بخش گفت‌وگو)");
            try { window.dispatchEvent(new CustomEvent("gamify:dm", { detail: { fresh: fresh } })); } catch (e) {}
          } else {
            try { var mt2 = readMeta(); mt2.knownServerMsg = knownServerMsg; writeMeta(mt2); } catch (e) {}
          }
        }).catch(function () {});
      }, idx * 800);
    });
  }

  // ---- اعلان‌های سرور → تост ----
  var seenNotices = {};
  try { seenNotices = readMeta().seenNotices || {}; } catch (e) {}
  function pollNotices() {
    if (!myServerId && !readMeta().serverId) return;
    fetch("/api/daily?kind=notifications", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
      if (!Array.isArray(rows)) return;
      var news = rows.filter(function (n) { return n && !n.seen && !seenNotices[n.id]; }).slice(0, 3);
      news.forEach(function (n, i) {
        seenNotices[n.id] = 1;
        setTimeout(function () { toast((n.title || "🔔 اعلان") + (n.body ? " — " + String(n.body).slice(0, 60) : "")); }, i * 1200);
      });
      try { var m = readMeta(); m.seenNotices = seenNotices; writeMeta(m); } catch (e) {}
      var unread = rows.filter(function (n) { return !n.seen; }).length;
      try { window.dispatchEvent(new CustomEvent("gamify:notices", { detail: { unread: unread, rows: rows } })); } catch (e) {}
    }).catch(function () {});
  }

  // ---- API عمومی برای پچ‌های دیگر ----
  window.__gamifyServer = {
    getServerId: function () { return myServerId || readMeta().serverId || null; },
    isReal: function (id) { return realIds.has(id); },
    syncNow: function () { return syncProfile("manual"); },
    ensureSynced: function () {
      var store = readStore();
      if (!store || !store.profile) return Promise.resolve(null);
      if (myServerId || readMeta().serverId) return syncProfile("auto").then(function (sv) { return sv || { id: myServerId || readMeta().serverId }; });
      return syncProfile("manual");
    },
    api: function (path, method, body, extraHeaders) {
      var headers = { "Content-Type": "application/json" };
      if (extraHeaders) for (var k in extraHeaders) headers[k] = extraHeaders[k];
      return fetch(path, { method: method || "GET", headers: headers, credentials: "include", body: body ? JSON.stringify(body) : undefined }).then(function (r) { return r.json(); });
    }
  };

  // ---- حلقه‌ها ----
  function tick() {
    try {
      var store = readStore();
      var meta = readMeta();
      if (!myServerId && meta.serverId) myServerId = meta.serverId;
      if (store && store.profile) {
        syncProfile("auto");
        mirrorContent();
        pumpOutgoingDMs();
        pumpIncomingDMs();
      }
    } catch (e) {}
  }

  function boot() {
    try {
      var meta = readMeta();
      if (meta.serverId) myServerId = meta.serverId;
    } catch (e) {}
    // همگام‌سازی اولیه با کمی تأخیر تا باندل بالا بیاید
    setTimeout(function () { tick(); fetchRealPlayers(); pollNotices(); }, 2500);
    setInterval(tick, 12000);
    setInterval(fetchRealPlayers, 60000);
    setInterval(pollNotices, 30000);
    setInterval(mirrorContent, 20000);
    // رویدادهای مهم
    document.addEventListener("visibilitychange", function () { if (!document.hidden) tick(); });
    window.addEventListener("beforeunload", function () { try { tick(); } catch (e) {} });
    window.addEventListener("gamify:profile-changed", function () { syncProfile("manual"); });
    // اگر پروفایل ساخته شد (ثبت‌نام تازه)، فوری همگام کن
    var lastProfileId = null;
    setInterval(function () {
      try {
        var s = readStore();
        var pid = s && s.profile ? s.profile.id : null;
        if (pid && pid !== lastProfileId) {
          lastProfileId = pid;
          syncProfile("manual").then(function (sv) { if (sv) { fetchRealPlayers(); toast("☁️ حسابت در سرور ذخیره شد ✅"); } });
        }
        if (!pid) lastProfileId = null;
      } catch (e) {}
    }, 3000);
    console.log("%c[gamify] sync فعال شد ✅ (مرورگر + سرور هم‌زمان)", "color:#7cd7b6");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
