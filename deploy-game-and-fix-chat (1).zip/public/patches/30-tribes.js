/* 🛡️ قبیله‌ها: ساخت قبیله توسط کاربر عادی + عضوگیری + نبرد قبیله‌ای + رتبه + تورنمنت */
(function () {
  "use strict";
  if (window.__gamifyTribes) return;
  window.__gamifyTribes = true;

  var LS_KEY = "gamify2-store-v2";
  var overlay = null;
  var state = { tab: "my", tribes: [], myTribe: null, myMembers: [], battles: [], tournaments: [], board: [], boardScope: "tribes", loading: "", q: "", quiz: null, createTour: false };
  var CATS = null;

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }

  function toast(msg) {
    var d = document.createElement("div");
    d.textContent = msg;
    d.style.cssText = "position:fixed;bottom:86px;right:16px;z-index:100999;background:#241a33;color:#fff;padding:10px 16px;border-radius:14px;font-size:13px;box-shadow:0 8px 30px rgba(0,0,0,.4);border:1px solid #a98cf7;font-family:Vazirmatn,sans-serif;max-width:min(92vw,400px);";
    document.body.appendChild(d);
    setTimeout(function () { d.style.transition = "opacity .4s"; d.style.opacity = "0"; setTimeout(function(){ d.remove(); }, 450); }, 3000);
  }

  // API با همگام‌سازی خودکار (فیکس ارور «ابتدا وارد بازی شو» با وجود لاگین بودن)
  function ensureServer() {
    if (window.__gamifyServer && window.__gamifyServer.ensureSynced) return window.__gamifyServer.ensureSynced();
    return Promise.resolve(null);
  }
  function api(path, method, body, retried) {
    return ensureServer().then(function () {
      return fetch(path, { method: method || "GET", headers: { "Content-Type": "application/json" }, credentials: "include", body: body ? JSON.stringify(body) : undefined })
        .then(function (r) { return r.json().then(function (j) { return { status: r.status, body: j }; }); })
        .then(function (res) {
          if (res.status === 401 && !retried) {
            // نشست منقضی؟ یک‌بار همگام‌سازی اجباری و تلاش مجدد
            if (window.__gamifyServer && window.__gamifyServer.syncNow) {
              return window.__gamifyServer.syncNow().then(function () {
                return fetch(path, { method: method || "GET", headers: { "Content-Type": "application/json" }, credentials: "include", body: body ? JSON.stringify(body) : undefined })
                  .then(function (r2) { return r2.json().then(function (j2) { return { status: r2.status, body: j2 }; }); });
              });
            }
          }
          return res;
        });
    });
  }

  function needLogin() {
    var st = readStore();
    return !(st && st.profile);
  }

  function goLogin() {
    closeOverlay();
    location.hash = "#home";
    setTimeout(function () {
      try {
        // دکمهٔ ورود باندل اصلی را پیدا و کلیک کن
        var btns = Array.from(document.querySelectorAll("button")).filter(function (b) { return /ورود به بازی|ورود \/ میهمان/.test(b.textContent || ""); });
        if (btns[0]) btns[0].click();
        else toast("از دکمهٔ «ورود به بازی» بالای صفحه وارد شو 🌱");
      } catch (e) { toast("از دکمهٔ «ورود به بازی» وارد شو 🌱"); }
    }, 600);
  }

  // ---------- داده‌ها ----------
  function loadCats() {
    if (CATS) return Promise.resolve(CATS);
    return fetch("/api/questions?category=_categories", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
      CATS = Array.isArray(rows) ? rows : [];
      return CATS;
    }).catch(function () { CATS = [{ id: "general", name: "اطلاعات عمومی" }, { id: "electric", name: "دنیای برق" }, { id: "safety", name: "ایمنی و نجات" }]; return CATS; });
  }
  function catName(id) {
    if (!CATS) return id;
    var c = CATS.filter(function (x) { return x.id === id; })[0];
    return c ? c.name : id;
  }

  function refreshAll() {
    state.loading = "در حال دریافت…";
    render();
    var p1 = api("/api/tribes?mine=1").then(function (r) {
      if (r.body && r.body.tribe) { state.myTribe = r.body.tribe; state.myMembers = r.body.members || []; }
      else { state.myTribe = null; state.myMembers = []; }
    }).catch(function () {});
    var p2 = api("/api/tribes" + (state.q ? ("?q=" + encodeURIComponent(state.q)) : "")).then(function (r) {
      state.tribes = Array.isArray(r.body) ? r.body : [];
    }).catch(function () {});
    var p3 = loadCats();
    return Promise.all([p1, p2, p3]).then(function () { state.loading = ""; render(); });
  }

  function refreshBattles() {
    if (!state.myTribe) { state.battles = []; render(); return Promise.resolve(); }
    state.loading = "در حال دریافت نبردها…"; render();
    return api("/api/tribes/" + state.myTribe.id + "?action=battles").then(function (r) {
      state.battles = Array.isArray(r.body) ? r.body : [];
      state.loading = ""; render();
    }).catch(function () { state.loading = ""; render(); });
  }

  function refreshTournaments() {
    state.loading = "در حال دریافت تورنمنت‌ها…"; render();
    return api("/api/tournaments").then(function (r) {
      state.tournaments = Array.isArray(r.body) ? r.body : [];
      state.loading = ""; render();
    }).catch(function () { state.loading = ""; render(); });
  }

  function refreshBoard() {
    state.loading = "در حال دریافت رتبه‌بندی…"; render();
    return fetch("/api/leaderboard?scope=" + state.boardScope, { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
      state.board = Array.isArray(rows) ? rows : [];
      state.loading = ""; render();
    }).catch(function () { state.loading = ""; render(); });
  }

  // ---------- کویییز نبرد/تورنمنت ----------
  function startQuiz(opts) {
    // opts: {title, questions, onFinish(score, correct)}
    state.quiz = { title: opts.title, questions: opts.questions, idx: 0, score: 0, correct: 0, picked: -1, timer: null, left: 0, onFinish: opts.onFinish, answers: [] };
    render();
    runQuestion();
  }
  function runQuestion() {
    var qz = state.quiz;
    if (!qz) return;
    var q = qz.questions[qz.idx];
    qz.picked = -1;
    qz.left = (q.seconds || 25);
    render();
    clearInterval(qz.timer);
    qz.timer = setInterval(function () {
      if (!state.quiz) { clearInterval(qz.timer); return; }
      qz.left -= 0.25;
      var bar = document.querySelector("[data-quiz-bar]");
      var num = document.querySelector("[data-quiz-left]");
      if (bar) bar.style.width = Math.max(0, (qz.left / (q.seconds || 25)) * 100) + "%";
      if (num) num.textContent = fa(Math.ceil(Math.max(0, qz.left)));
      if (qz.left <= 0) { clearInterval(qz.timer); pickOption(-1); }
    }, 250);
  }
  function pickOption(i) {
    var qz = state.quiz;
    if (!qz || qz.picked !== -1) return;
    clearInterval(qz.timer);
    qz.picked = i;
    var q = qz.questions[qz.idx];
    var ok = i === q.correct;
    if (ok) {
      var timeBonus = Math.max(0, Math.round((qz.left / (q.seconds || 25)) * 50));
      qz.score += 100 + timeBonus;
      qz.correct++;
    }
    qz.answers.push({ q: q.id, pick: i, ok: ok });
    render();
    setTimeout(function () {
      if (!state.quiz) return;
      qz.idx++;
      if (qz.idx >= qz.questions.length) finishQuiz();
      else runQuestion();
    }, 1400);
  }
  function finishQuiz() {
    var qz = state.quiz;
    if (!qz) return;
    clearInterval(qz.timer);
    var cb = qz.onFinish;
    var score = qz.score, correct = qz.correct, total = qz.questions.length;
    state.quiz = { done: true, title: qz.title, score: score, correct: correct, total: total };
    render();
    // پاداش محلی فوری (سرور هم جداگانه اضافه می‌کند؛ max نگه می‌دارد)
    try {
      var st = readStore();
      if (st && st.profile) {
        st.profile.xp = (st.profile.xp || 0) + Math.round(score / 10);
        st.profile.coins = (st.profile.coins || 0) + correct * 4;
        st.profile.played = (st.profile.played || 0) + 1;
        if (correct >= Math.ceil(total * 0.7)) st.profile.wins = (st.profile.wins || 0) + 1;
        localStorage.setItem(LS_KEY, JSON.stringify(st));
        if (window.__gamifyServer) window.__gamifyServer.syncNow();
      }
    } catch (e) {}
    if (window.__gamifyConfetti && correct >= Math.ceil(total * 0.6)) { try { window.__gamifyConfetti(); } catch (e) {} }
    if (cb) cb(score, correct);
  }

  // ---------- اکشن‌ها ----------
  function doCreateTribe(form) {
    var fd = new FormData(form);
    var payload = { name: fd.get("name"), tag: fd.get("tag"), description: fd.get("description"), motto: fd.get("motto"), logoEmoji: fd.get("emoji"), logoColor: fd.get("color"), isPublic: fd.get("vis") !== "private" };
    state.loading = "در حال ساخت قبیله…"; render();
    api("/api/tribes", "POST", payload).then(function (r) {
      if (r.body && r.body.ok) { toast("🛡️ قبیله ساخته شد!"); state.tab = "my"; refreshAll(); }
      else { state.loading = ""; render(); toast("⚠️ " + ((r.body && (r.body.error || r.body.message)) || "خطا")); }
    });
  }
  function doJoin(id, code) {
    state.loading = "در حال پیوستن…"; render();
    api("/api/tribes/" + id + "?action=join", "POST", { inviteCode: code || "" }).then(function (r) {
      if (r.body && r.body.ok) { toast("🎉 " + (r.body.message || "عضو شدی!")); state.tab = "my"; refreshAll(); }
      else {
        state.loading = ""; render();
        var msg = (r.body && (r.body.error || r.body.message)) || "خطا";
        if (/خصوصی|کد دعوت/.test(msg)) {
          var c = prompt("🔑 این قبیله خصوصی است؛ کد دعوت را وارد کن:");
          if (c) doJoin(id, c);
          else toast("⚠️ " + msg);
        } else toast("⚠️ " + msg);
      }
    });
  }
  function doLeave() {
    if (!state.myTribe) return;
    if (!confirm("از قبیلهٔ «" + state.myTribe.name + "» خارج می‌شوی؟")) return;
    api("/api/tribes/" + state.myTribe.id + "?action=leave", "POST", {}).then(function (r) {
      toast(r.body && r.body.message ? r.body.message : "خارج شدی");
      state.tab = "all"; refreshAll();
    });
  }
  function doInvite() {
    if (!state.myTribe) return;
    var v = prompt("نام دقیق بازیکن یا شناسه‌اش را بنویس تا دعوت شود:");
    if (!v) return;
    var payload = /^[a-z0-9-]{4,}$/i.test(v) && v.length > 12 ? { userId: v } : { userName: v };
    api("/api/tribes/" + state.myTribe.id + "?action=invite", "POST", payload).then(function (r) {
      toast(r.body && (r.body.message || r.body.error) || "انجام شد");
    });
  }
  function doChallenge(enemyId) {
    if (!state.myTribe) { toast("⚠️ اول باید عضو یک قبیله باشی!"); return; }
    loadCats().then(function (cats) {
      var names = cats.map(function (c, i) { return (i + 1) + ") " + c.name; }).join("\n");
      var pick = prompt("⚔️ دستهٔ نبرد را انتخاب کن (عدد بزن):\n" + names, "1");
      if (!pick) return;
      var idx = Math.max(1, Math.min(cats.length, parseInt(pick, 10) || 1)) - 1;
      var cat = cats[idx].id;
      state.loading = "در حال شروع نبرد…"; render();
      api("/api/tribes/" + enemyId + "?action=challenge", "POST", { category: cat }).then(function (r) {
        if (r.body && r.body.ok) { toast("⚔️ نبرد آغاز شد!"); state.tab = "battles"; refreshAll().then(refreshBattles); }
        else { state.loading = ""; render(); toast("⚠️ " + ((r.body && (r.body.error || r.body.message)) || "خطا")); }
      });
    });
  }
  function playBattle(battleId) {
    var b = state.battles.filter(function (x) { return x.id === battleId; })[0];
    if (!b) { toast("نبرد پیدا نشد"); return; }
    var qs = b.questions || [];
    if (!qs.length) { toast("سؤالی برای این نبرد ثبت نشده"); return; }
    startQuiz({
      title: "⚔️ نبرد قبیله‌ای — " + catName(b.category),
      questions: qs,
      onFinish: function (score, correct) {
        api("/api/tribes/" + b.tribeA + "?action=battle-answer", "POST", { battleId: battleId, score: score, correct: correct }).then(function (r) {
          if (r.body && r.body.ok) toast("✅ نتیجه ثبت شد! امتیاز: " + fa(score));
          refreshBattles();
        });
      }
    });
  }
  function doCreateTournament(form) {
    var fd = new FormData(form);
    state.loading = "در حال ساخت تورنمنت…"; render();
    api("/api/tournaments?action=create", "POST", { title: fd.get("title"), category: fd.get("category"), days: Number(fd.get("days") || 7), description: fd.get("description"), tribeOnly: !!state.myTribe && fd.get("scope") === "tribe" }).then(function (r) {
      if (r.body && r.body.ok) { toast("🏆 تورنمنت ساخته شد!"); state.createTour = false; refreshTournaments(); }
      else { state.loading = ""; render(); toast("⚠️ " + ((r.body && (r.body.error || r.body.message)) || "خطا")); }
    });
  }
  function playTournament(tid) {
    state.loading = "در حال ورود به تورنمنت…"; render();
    api("/api/tournaments?action=join", "POST", { id: tid }).then(function (r) {
      if (r.body && r.body.questions) {
        var t = state.tournaments.filter(function (x) { return x.id === tid; })[0] || { title: "تورنمنت" };
        var qs = r.body.questions;
        if (!qs.length) { state.loading = ""; render(); toast("سؤالی ثبت نشده"); return; }
        startQuiz({
          title: "🏆 " + t.title,
          questions: qs,
          onFinish: function (score) {
            api("/api/tournaments?action=submit", "POST", { id: tid, score: score }).then(function () { refreshTournaments(); });
          }
        });
      } else { state.loading = ""; render(); toast("⚠️ " + ((r.body && (r.body.error || r.body.message)) || "خطا")); }
    });
  }

  // ---------- رندر ----------
  function ensureOverlay() {
    if (overlay) return overlay;
    overlay = document.createElement("div");
    overlay.id = "gamify-tribes-overlay";
    overlay.className = "gamify-overlay";
    document.body.appendChild(overlay);
    return overlay;
  }
  function closeOverlay() {
    if (overlay) overlay.classList.remove("open");
    if ((location.hash || "").indexOf("#tribe") === 0 || (location.hash || "").indexOf("#tribes") === 0) {
      try { history.replaceState(null, "", "#home"); } catch (e) { location.hash = "#home"; }
    }
  }
  function openOverlay(tab) {
    if (tab) state.tab = tab;
    ensureOverlay().classList.add("open");
    if (needLogin()) { render(); return; }
    if (state.tab === "battles") refreshAll().then(refreshBattles);
    else if (state.tab === "tournaments") refreshAll().then(refreshTournaments);
    else if (state.tab === "board") refreshAll().then(refreshBoard);
    else refreshAll();
  }

  function tabsHtml() {
    var tabs = [["my", "🛡️ قبیلهٔ من"], ["all", "🔍 همهٔ قبیله‌ها"], ["create", "➕ ساخت قبیله"], ["battles", "⚔️ نبردها"], ["tournaments", "🏆 تورنمنت‌ها"], ["board", "👑 رتبه‌بندی"]];
    return '<div class="gamify-tabs">' + tabs.map(function (t) {
      return '<button data-tab="' + t[0] + '" class="' + (state.tab === t[0] ? "active" : "") + '">' + t[1] + "</button>";
    }).join("") + "</div>";
  }

  function quizHtml() {
    var qz = state.quiz;
    if (!qz) return "";
    if (qz.done) {
      var pct = qz.total ? Math.round((qz.correct / qz.total) * 100) : 0;
      var emoji = pct >= 80 ? "🏆" : pct >= 60 ? "🎉" : pct >= 40 ? "💪" : "📚";
      return '<div class="gamify-quiz"><h3>' + esc(qz.title) + '</h3><div class="gamify-quiz-done"><div style="font-size:56px;">' + emoji + '</div>' +
        "<h2>امتیاز: " + fa(qz.score) + "</h2><p>" + fa(qz.correct) + " پاسخ درست از " + fa(qz.total) + " (" + fa(pct) + "٪)</p>" +
        '<button class="gamify-btn primary" data-act="quiz-back">بازگشت</button></div></div>';
    }
    var q = qz.questions[qz.idx];
    var opts = q.options.map(function (o, i) {
      var cls = "gamify-opt";
      if (qz.picked !== -1) {
        if (i === q.correct) cls += " correct";
        else if (i === qz.picked) cls += " wrong";
      }
      return '<button class="' + cls + '" data-opt="' + i + '" ' + (qz.picked !== -1 ? "disabled" : "") + ">" + esc(o) + "</button>";
    }).join("");
    var expl = "";
    if (qz.picked !== -1 && q.explanation) expl = '<div class="gamify-expl">💡 ' + esc(q.explanation) + "</div>";
    return '<div class="gamify-quiz"><div class="gamify-quiz-top"><b>' + esc(qz.title) + "</b>" +
      "<span>سؤال " + fa(qz.idx + 1) + " از " + fa(qz.questions.length) + " · ⏱ <span data-quiz-left>" + fa(Math.ceil(qz.left)) + "</span> ثانیه · ⭐ " + fa(qz.score) + "</span></div>" +
      '<div class="gamify-timer"><span data-quiz-bar style="width:100%"></span></div>' +
      '<h3 class="gamify-q">' + esc(q.title) + "</h3>" +
      '<div class="gamify-opts">' + opts + "</div>" + expl + "</div>";
  }

  function myTribeHtml() {
    if (!state.myTribe) {
      return '<div class="gamify-empty"><div style="font-size:52px;">🛡️</div><h3>هنوز عضو هیچ قبیله‌ای نیستی!</h3>' +
        "<p>خودت یک قبیله بساز و رهبرش شو، یا به قبیلهٔ دوستانت بپیوند.</p>" +
        '<div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;"><button class="gamify-btn primary" data-tab="create">➕ ساخت قبیله</button><button class="gamify-btn" data-tab="all">🔍 دیدن قبیله‌ها</button></div></div>';
    }
    var t = state.myTribe;
    var members = state.myMembers.map(function (m) {
      var role = m.role === "owner" ? "👑 رهبر" : m.role === "admin" ? "🛡️ معاون" : "⚔️ عضو";
      return '<div class="gamify-member"><span class="gamify-mavatar">' + (m.online ? "🟢" : "⚪") + "</span><div><b>" + esc(m.name) + "</b><small>" + role + " · سطح " + fa(m.level || 1) + " · " + fa(m.xp || 0) + " XP</small></div></div>";
    }).join("");
    return '<div class="gamify-tribe-head" style="--tribe:' + esc(t.logoColor || "#a98cf7") + '"><div class="gamify-tribe-logo">' + esc(t.logoEmoji || "🛡️") + "</div>" +
      "<div><h2>" + esc(t.name) + ' <small>[' + esc(t.tag || "") + "]</small></h2>" +
      "<p>«" + esc(t.motto || "") + "»</p>" +
      "<p class='gamify-desc'>" + esc(t.description || "") + "</p>" +
      '<div class="gamify-stats"><span>👥 ' + fa(t.memberCount || state.myMembers.length) + " عضو</span><span>⭐ " + fa(t.xp || 0) + " XP</span><span>🏆 " + fa(t.wins || 0) + " برد</span><span>🎖 رتبه " + fa(t.rating || 1000) + "</span>" + (t.isPublic ? "<span>🌍 عمومی</span>" : "<span>🔒 خصوصی · کد: " + esc(t.inviteCode || "") + "</span>") + "</div></div></div>" +
      '<div class="gamify-row"><button class="gamify-btn primary" data-act="invite">✉️ دعوت دوست</button><button class="gamify-btn" data-act="battles">⚔️ نبردها</button><button class="gamify-btn danger" data-act="leave">خروج از قبیله</button></div>' +
      "<h3>اعضا (" + fa(state.myMembers.length) + ")</h3><div class='gamify-members'>" + members + "</div>";
  }

  function allTribesHtml() {
    var list = state.tribes.map(function (t) {
      var btn = t.isMember ? '<span class="gamify-joined">✅ عضوی</span>' : '<button class="gamify-btn sm primary" data-join="' + t.id + '">پیوستن</button>';
      var war = (!t.isMember && state.myTribe) ? '<button class="gamify-btn sm war" data-war="' + t.id + '">⚔️ چالش نبرد</button>' : "";
      return '<div class="gamify-tribe-card" style="--tribe:' + esc(t.logoColor || "#a98cf7") + '"><div class="gamify-tribe-logo sm">' + esc(t.logoEmoji || "🛡️") + "</div>" +
        "<div class='gamify-tribe-info'><b>" + esc(t.name) + " <small>[" + esc(t.tag || "") + "]</small></b><small>" + esc(t.motto || "") + "</small>" +
        "<small>👥 " + fa(t.memberCount || 0) + " · ⭐ " + fa(t.xp || 0) + " · 🏆 " + fa(t.wins || 0) + (t.isPublic ? "" : " · 🔒") + "</small></div>" +
        "<div class='gamify-tribe-acts'>" + btn + war + "</div></div>";
    }).join("");
    return '<div class="gamify-search"><input data-search placeholder="🔍 جست‌وجوی قبیله…" value="' + esc(state.q) + '"><button class="gamify-btn sm" data-act="search">جست‌وجو</button></div>' +
      (list || '<div class="gamify-empty">هنوز قبیله‌ای ساخته نشده؛ اولین رهبر باش! 🛡️</div>');
  }

  function createHtml() {
    if (state.myTribe) return '<div class="gamify-empty">تو الان عضو قبیلهٔ «' + esc(state.myTribe.name) + '» هستی.<br>اول از آن خارج شو تا قبیلهٔ تازه بسازی.</div>';
    return '<form class="gamify-form" data-form="tribe"><h3>➕ ساخت قبیلهٔ تازه</h3>' +
      '<p class="gamify-hint">مثل یک ادمین! قبیله‌ات را بساز، دوستانت را دعوت کن و با قبیله‌های دیگر بجنگ. ⚔️</p>' +
      '<label>نام قبیله *<input name="name" required minlength="3" maxlength="30" placeholder="مثلاً: سیمبانان شمال"></label>' +
      '<label>تگ کوتاه (حداکثر ۸ حرف)<input name="tag" maxlength="8" placeholder="مثلاً: SIM"></label>' +
      '<div class="gamify-grid2"><label>نشان<input name="emoji" value="🛡️" maxlength="8"></label><label>رنگ قبیله<input type="color" name="color" value="#a98cf7"></label></div>' +
      '<label>شعار قبیله<input name="motto" maxlength="120" value="با هم قوی‌تریم! 💪"></label>' +
      '<label>توضیح<textarea name="description" maxlength="300" placeholder="قبیلهٔ ما برای چه کسانی است؟"></textarea></label>' +
      '<label>دسترسی<select name="vis"><option value="public">🌍 عمومی — همه می‌توانند عضو شوند</option><option value="private">🔒 خصوصی — فقط با کد دعوت</option></select></label>' +
      '<button class="gamify-btn primary full">🛡️ ساخت قبیله</button></form>';
  }

  function battlesHtml() {
    if (!state.myTribe) return '<div class="gamify-empty">اول باید عضو یک قبیله باشی تا نبرد ببینی! 🛡️</div>';
    if (!state.battles.length) return '<div class="gamify-empty"><div style="font-size:52px;">⚔️</div><h3>هنوز نبردی ثبت نشده</h3><p>از تب «همهٔ قبیله‌ها» یک قبیله را به نبرد دعوت کن!</p><button class="gamify-btn primary" data-tab="all">🔍 انتخاب حریف</button></div>';
    return state.battles.map(function (b) {
      var mine = b.tribeA === state.myTribe.id;
      var myScore = mine ? b.scoreA : b.scoreB;
      var opScore = mine ? b.scoreB : b.scoreA;
      var st = b.status === "active" ? "🔥 فعال" : "🏁 پایان‌یافته";
      return '<div class="gamify-battle"><div><b>⚔️ نبرد ' + esc(catName(b.category)) + "</b><small>" + st + " · امتیاز ما: " + fa(myScore) + " — حریف: " + fa(opScore) + "</small></div>" +
        (b.status === "active" ? '<button class="gamify-btn primary sm" data-battle="' + b.id + '">🎮 ورود به نبرد</button>' : "") + "</div>";
    }).join("");
  }

  function tournamentsHtml() {
    var createBtn = '<div class="gamify-row"><button class="gamify-btn primary" data-act="tour-toggle">➕ ساخت تورنمنت تازه</button></div>';
    var form = "";
    if (state.createTour) {
      var catOpts = (CATS || []).map(function (c) { return '<option value="' + c.id + '">' + esc(c.name) + "</option>"; }).join("");
      form = '<form class="gamify-form" data-form="tour"><h3>🏆 ساخت تورنمنت</h3>' +
        '<label>عنوان *<input name="title" required minlength="4" maxlength="60" placeholder="مثلاً: جام برق تابستان"></label>' +
        '<div class="gamify-grid2"><label>دسته<select name="category">' + catOpts + '</select></label><label>مدت (روز)<input type="number" name="days" value="7" min="1" max="30"></label></div>' +
        '<label>توضیح<textarea name="description" maxlength="300"></textarea></label>' +
        '<label>مخاطب<select name="scope"><option value="all">🌍 همه</option><option value="tribe">🛡️ فقط قبیله‌ها</option></select></label>' +
        '<button class="gamify-btn primary full">🏆 ساخت تورنمنت</button></form>';
    }
    var list = state.tournaments.map(function (t) {
      var badge = !t.open ? "⏳ بسته" : t.orgLocked ? "🏢 ویژهٔ سازمان دیگر" : t.orgId ? "🏢 ویژهٔ سازمان شما ✅" : "🌍 آزاد";
      var btn = (!t.open || t.orgLocked) ? "" : '<button class="gamify-btn primary sm" data-tour="' + t.id + '">' + (t.joined ? "🎮 ادامه (" + fa(t.myScore || 0) + ")" : "🎮 شرکت") + "</button>";
      return '<div class="gamify-tribe-card"><div class="gamify-tribe-logo sm">🏆</div><div class="gamify-tribe-info"><b>' + esc(t.title) + '</b><small>' + esc(catName(t.category)) + " · " + badge + (t.tribeOnly ? " · 🛡️ قبیله‌ای" : "") + "</small><small>" + esc(t.description || "") + "</small></div><div class='gamify-tribe-acts'>" + btn + "</div></div>";
    }).join("");
    return createBtn + form + (list || '<div class="gamify-empty">تورنمنتی نیست.</div>');
  }

  function boardHtml() {
    var scopes = [["tribes", "🛡️ قبیله‌ها"], ["players", "👑 بازیکنان"], ["week", "🔥 هفته"]];
    var head = '<div class="gamify-row">' + scopes.map(function (s) {
      return '<button class="gamify-btn sm ' + (state.boardScope === s[0] ? "primary" : "") + '" data-scope="' + s[0] + '">' + s[1] + "</button>";
    }).join("") + "</div>";
    var rows = "";
    if (state.boardScope === "tribes") {
      rows = state.board.map(function (t) {
        var medal = t.rank === 1 ? "🥇" : t.rank === 2 ? "🥈" : t.rank === 3 ? "🥉" : fa(t.rank) + ".";
        return '<div class="gamify-rank"><b>' + medal + " " + esc(t.logoEmoji || "🛡️") + " " + esc(t.name) + '</b><span>⭐ ' + fa(t.xp || 0) + " · 👥 " + fa(t.memberCount || 0) + " · 🏆 " + fa(t.wins || 0) + "</span></div>";
      }).join("");
    } else {
      rows = state.board.map(function (u) {
        var medal = u.rank === 1 ? "🥇" : u.rank === 2 ? "🥈" : u.rank === 3 ? "🥉" : fa(u.rank) + ".";
        return '<div class="gamify-rank"><b>' + medal + " " + esc(u.name) + '</b><span>⭐ ' + fa(u.xp || 0) + " · 🏆 " + fa(u.cups || 0) + " · 🔥 " + fa(u.streak || 0) + "</span></div>";
      }).join("");
    }
    return head + (rows || '<div class="gamify-empty">داده‌ای نیست.</div>');
  }

  function render() {
    var ov = ensureOverlay();
    if (!ov.classList.contains("open")) return;
    if (state.quiz) {
      ov.innerHTML = '<div class="gamify-modal">' + '<div class="gamify-modal-head"><b>🛡️ قبیله‌ها</b><button data-act="close">✕</button></div>' + quizHtml() + "</div>";
      bind(ov);
      return;
    }
    if (needLogin()) {
      ov.innerHTML = '<div class="gamify-modal"><div class="gamify-modal-head"><b>🛡️ قبیله‌ها</b><button data-act="close">✕</button></div>' +
        '<div class="gamify-empty"><div style="font-size:52px;">🌱</div><h3>ابتدا وارد بازی شو</h3><p>برای ساخت و دیدن قبیله‌ها باید وارد بازی شده باشی.</p><button class="gamify-btn primary" data-act="login">🚀 ورود به بازی</button></div></div>';
      bind(ov);
      return;
    }
    var body = "";
    if (state.tab === "my") body = myTribeHtml();
    else if (state.tab === "all") body = allTribesHtml();
    else if (state.tab === "create") body = createHtml();
    else if (state.tab === "battles") body = battlesHtml();
    else if (state.tab === "tournaments") body = tournamentsHtml();
    else if (state.tab === "board") body = boardHtml();
    ov.innerHTML = '<div class="gamify-modal"><div class="gamify-modal-head"><b>🛡️ قبیله‌ها</b><button data-act="close">✕</button></div>' +
      tabsHtml() + (state.loading ? '<div class="gamify-loading">' + esc(state.loading) + "</div>" : "") +
      '<div class="gamify-body">' + body + "</div></div>";
    bind(ov);
  }

  function bind(ov) {
    ov.querySelectorAll("[data-tab]").forEach(function (b) {
      b.addEventListener("click", function () {
        state.tab = b.getAttribute("data-tab"); state.quiz = null;
        if (state.tab === "battles") refreshBattles();
        else if (state.tab === "tournaments") refreshTournaments();
        else if (state.tab === "board") refreshBoard();
        else refreshAll();
      });
    });
    ov.querySelectorAll("[data-act]").forEach(function (b) {
      b.addEventListener("click", function () {
        var a = b.getAttribute("data-act");
        if (a === "close") closeOverlay();
        else if (a === "login") goLogin();
        else if (a === "invite") doInvite();
        else if (a === "leave") doLeave();
        else if (a === "battles") { state.tab = "battles"; refreshBattles(); }
        else if (a === "search") { var inp = ov.querySelector("[data-search]"); state.q = inp ? inp.value : ""; refreshAll(); }
        else if (a === "tour-toggle") { state.createTour = !state.createTour; render(); }
        else if (a === "quiz-back") { state.quiz = null; render(); if (state.tab === "battles") refreshBattles(); else if (state.tab === "tournaments") refreshTournaments(); }
      });
    });
    ov.querySelectorAll("[data-join]").forEach(function (b) { b.addEventListener("click", function () { doJoin(b.getAttribute("data-join")); }); });
    ov.querySelectorAll("[data-war]").forEach(function (b) { b.addEventListener("click", function () { doChallenge(b.getAttribute("data-war")); }); });
    ov.querySelectorAll("[data-battle]").forEach(function (b) { b.addEventListener("click", function () { playBattle(b.getAttribute("data-battle")); }); });
    ov.querySelectorAll("[data-tour]").forEach(function (b) { b.addEventListener("click", function () { playTournament(b.getAttribute("data-tour")); }); });
    ov.querySelectorAll("[data-scope]").forEach(function (b) { b.addEventListener("click", function () { state.boardScope = b.getAttribute("data-scope"); refreshBoard(); }); });
    ov.querySelectorAll("[data-opt]").forEach(function (b) { b.addEventListener("click", function () { pickOption(Number(b.getAttribute("data-opt"))); }); });
    ov.querySelectorAll('[data-form="tribe"]').forEach(function (f) { f.addEventListener("submit", function (e) { e.preventDefault(); doCreateTribe(f); }); });
    ov.querySelectorAll('[data-form="tour"]').forEach(function (f) { f.addEventListener("submit", function (e) { e.preventDefault(); doCreateTournament(f); }); });
    var si = ov.querySelector("[data-search]");
    if (si) si.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); state.q = si.value; refreshAll(); } });
  }

  // ---------- تزریق رتبهٔ قبیله‌ها در صفحهٔ تالار قهرمانان خود بازی ----------
  var lastBoardInject = 0;
  function injectTribeBoard() {
    try {
      if ((location.hash || "").indexOf("#leaderboard") !== 0) return;
      if (Date.now() - lastBoardInject < 15000) return;
      if (document.querySelector("[data-gamify-tribe-board]")) return;
      lastBoardInject = Date.now();
      fetch("/api/leaderboard?scope=tribes", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
        if (!Array.isArray(rows) || !rows.length) return;
        if (document.querySelector("[data-gamify-tribe-board]")) return;
        var root = document.getElementById("root");
        if (!root) return;
        var box = document.createElement("div");
        box.setAttribute("data-gamify-tribe-board", "1");
        box.style.cssText = "margin:12px;padding:14px 16px;border-radius:16px;background:linear-gradient(135deg,rgba(169,140,247,.14),rgba(248,197,108,.10));border:1px solid rgba(169,140,247,.45);font-family:Vazirmatn,sans-serif;";
        var top = rows.slice(0, 5).map(function (t, i) {
          var medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : (i + 1) + ".";
          return "<div style='display:flex;justify-content:space-between;font-size:13px;padding:3px 0;'><span>" + medal + " " + esc(t.logoEmoji || "🛡️") + " " + esc(t.name) + "</span><span style='opacity:.8;'>⭐ " + fa(t.xp || 0) + "</span></div>";
        }).join("");
        box.innerHTML = "<div style='font-weight:800;margin-bottom:8px;'>🛡️ برترین قبیله‌ها <button data-goto-tribes style='float:left;background:#a98cf7;border:none;color:#17111f;font-weight:800;border-radius:10px;padding:4px 12px;cursor:pointer;font-family:inherit;'>دیدن همه</button></div>" + top;
        var first = root.firstElementChild;
        if (first) first.insertBefore(box, first.firstChild);
        else root.appendChild(box);
        var g = box.querySelector("[data-goto-tribes]");
        if (g) g.addEventListener("click", function () { location.hash = "#tribes"; });
        setTimeout(function () { try { if ((location.hash || "").indexOf("#leaderboard") !== 0) box.remove(); } catch (e) {} }, 30000);
      }).catch(function () {});
    } catch (e) {}
  }

  // ---------- دکمهٔ شناور + روتر ----------
  function mountFab() {
    if (document.getElementById("gamify-tribes-fab")) return;
    var b = document.createElement("button");
    b.id = "gamify-tribes-fab";
    b.innerHTML = "🛡️";
    b.title = "قبیله‌ها";
    document.body.appendChild(b);
    b.addEventListener("click", function () { location.hash = "#tribes"; });
    // نشان اعلان نبرد
    setInterval(function () {
      try {
        var st = readStore();
        if (!st || !st.profile) return;
        // اگر دعوت/نبرد تازه هست، پالس بزن (ساده: هر ۲ دقیقه چشمک)
      } catch (e) {}
    }, 60000);
  }

  function route() {
    var h = location.hash || "";
    if (h.indexOf("#tribes") === 0 || h.indexOf("#tribe") === 0) {
      var parts = h.replace("#", "").split("/");
      if (parts[0] === "tribes" && parts[1]) openOverlay(parts[1]);
      else openOverlay(state.tab || "my");
    } else {
      if (overlay) overlay.classList.remove("open");
    }
    setTimeout(injectTribeBoard, 900);
  }

  // تزریق لینک قبیله در منوی کناری خود بازی (اگر پیدا شد)
  function injectNavLink() {
    try {
      if (document.querySelector("[data-gamify-nav-tribes]")) return;
      var links = Array.from(document.querySelectorAll("a")).filter(function (a) { return (a.getAttribute("href") || "") === "#leagues" || /لیگ‌ها/.test(a.textContent || ""); });
      if (!links.length) return;
      var ref = links[0];
      var a = document.createElement("a");
      a.href = "#tribes";
      a.className = ref.className;
      a.setAttribute("data-gamify-nav-tribes", "1");
      a.innerHTML = ref.innerHTML.replace(/لیگ‌ها/g, "قبیله‌ها").replace(/medal|chart/gi, "shield");
      // اگر جایگزینی تمیز نشد، ساده بساز
      if (a.textContent.indexOf("قبیله") === -1) a.innerHTML = "🛡️ <span>قبیله‌ها</span>";
      ref.parentElement.insertBefore(a, ref.nextSibling);
    } catch (e) {}
  }

  function boot() {
    setTimeout(mountFab, 3500);
    window.addEventListener("hashchange", route);
    setInterval(injectTribeBoard, 5000);
    setInterval(injectNavLink, 4000);
    setTimeout(route, 3000);
    setTimeout(injectNavLink, 5000);
    document.addEventListener("click", function (e) {
      var t = e.target && e.target.closest ? e.target.closest("#gamify-tribes-overlay") : null;
      if (t && e.target === t) closeOverlay();
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && state.quiz && !state.quiz.done) { /* خروج از کوییز با نگه‌داشتن */ } else if (e.key === "Escape") closeOverlay(); });
    console.log("%c[gamify] tribes فعال شد ✅", "color:#a98cf7");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
