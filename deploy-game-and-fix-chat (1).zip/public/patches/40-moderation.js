/* 📋 پنل زندهٔ مدیر: تأیید/ویرایش پست و استوری + دیدن کاربران — بدون اخلال در اتوماسیون */
(function () {
  "use strict";
  if (window.__gamifyModeration) return;
  window.__gamifyModeration = true;

  var LS_KEY = "gamify2-store-v2";
  var overlay = null;
  var isAdmin = false;
  var serverAdmin = false;
  var state = { tab: "posts", posts: [], stories: [], users: [], overview: null, loading: "" };

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }
  function timeAgo(t) {
    var d = Date.now() - (t || 0);
    if (d < 60000) return "لحظاتی پیش";
    if (d < 3600000) return fa(Math.floor(d / 60000)) + " دقیقه پیش";
    if (d < 86400000) return fa(Math.floor(d / 3600000)) + " ساعت پیش";
    return fa(Math.floor(d / 86400000)) + " روز پیش";
  }

  function toast(msg) {
    var d = document.createElement("div");
    d.textContent = msg;
    d.style.cssText = "position:fixed;bottom:86px;right:16px;z-index:101999;background:#241a33;color:#fff;padding:10px 16px;border-radius:14px;font-size:13px;border:1px solid #7cd7b6;font-family:Vazirmatn,sans-serif;max-width:min(92vw,400px);";
    document.body.appendChild(d);
    setTimeout(function () { d.style.transition = "opacity .4s"; d.style.opacity = "0"; setTimeout(function(){ d.remove(); }, 450); }, 3000);
  }

  function headers() {
    var h = { "Content-Type": "application/json" };
    if (!serverAdmin) h["x-local-admin"] = "1"; // مدیر محلی بازی اصلی
    return h;
  }

  function checkAdmin() {
    var st = readStore();
    var local = !!(st && (st.admin === true || (st.profile && st.profile.role === "admin")));
    if (local) { isAdmin = true; mountFab(); }
    // سرور هم چک شود
    fetch("/api/me", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (me) {
      if (me && me.role === "admin") { serverAdmin = true; isAdmin = true; mountFab(); }
      updateBadge();
    }).catch(function () {});
    return local;
  }

  function updateBadge() {
    var fab = document.getElementById("gamify-mod-fab");
    if (!fab || !isAdmin) return;
    fetch("/api/moderation", { credentials: "include", headers: headers() }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || j.error) {
        // فقط محلی‌ها را بشمار
        var st = readStore();
        var n = st ? ((st.posts || []).filter(function (p) { return p.status === "pending"; }).length + (st.stories || []).filter(function (s) { return s.status === "pending"; }).length) : 0;
        fab.innerHTML = "📋" + (n ? '<span class="gamify-fab-badge">' + fa(n) + "</span>" : "");
        return;
      }
      var total = (j.posts || []).length + (j.stories || []).length;
      fab.innerHTML = "📋" + (total ? '<span class="gamify-fab-badge">' + fa(total) + "</span>" : "");
    }).catch(function () {});
  }

  function refresh() {
    state.loading = "در حال دریافت صف زنده…";
    render();
    var jobs = [];
    jobs.push(fetch("/api/moderation", { credentials: "include", headers: headers() }).then(function (r) { return r.json(); }).then(function (j) {
      if (j && !j.error) { state.posts = j.posts || []; state.stories = j.stories || []; }
      else { state.posts = []; state.stories = []; }
    }).catch(function () { state.posts = []; state.stories = []; }));
    if (state.tab === "users" || state.tab === "overview") {
      jobs.push(fetch("/api/admin?" + (state.tab === "users" ? "view=users" : "view=overview"), { credentials: "include", headers: headers() }).then(function (r) { return r.json(); }).then(function (j) {
        if (state.tab === "users") state.users = Array.isArray(j) ? j : [];
        else state.overview = j && !j.error ? j : null;
      }).catch(function () {}));
    }
    return Promise.all(jobs).then(function () { state.loading = ""; render(); updateBadge(); });
  }

  function decide(kind, id, status) {
    // ۱) سرور
    fetch("/api/moderation?action=decide", { method: "POST", credentials: "include", headers: headers(), body: JSON.stringify({ kind: kind, id: id, status: status }) }).catch(function(){});
    // ۲) محلی (بازی اصلی) — همان لحظه اعمال شود
    try {
      var st = readStore();
      if (st) {
        var changed = false;
        if (kind === "post") (st.posts || []).forEach(function (p) { if (String(p.id) === String(id)) { p.status = status; changed = true; } });
        else (st.stories || []).forEach(function (s) { if (String(s.id) === String(id)) { s.status = status; changed = true; } });
        if (changed) localStorage.setItem(LS_KEY, JSON.stringify(st));
      }
    } catch (e) {}
    toast(status === "approved" ? "✅ منتشر شد" : "🗑️ رد شد");
    setTimeout(refresh, 600);
  }

  function editItem(kind, id) {
    var current = "";
    try {
      var st = readStore();
      if (kind === "post") {
        var srv = state.posts.filter(function (p) { return String(p.id) === String(id); })[0];
        current = srv ? srv.body : ((st.posts || []).filter(function (p) { return String(p.id) === String(id); })[0] || {}).body || "";
      } else {
        var srv2 = state.stories.filter(function (s) { return String(s.id) === String(id); })[0];
        current = srv2 ? (srv2.title + "\n\n— گزینه‌ها: " + (srv2.options || []).join(" / ")) : "";
      }
    } catch (e) {}
    var next = prompt(kind === "post" ? "✏️ ویرایش متن پست:" : "✏️ ویرایش عنوان استوری (سطر اول):", current);
    if (next == null) return;
    var body = kind === "post" ? { kind: kind, id: id, status: "approved", body: next.slice(0, 4000) } : { kind: kind, id: id, status: "approved", title: next.split("\n")[0].slice(0, 500) };
    fetch("/api/moderation?action=edit", { method: "POST", credentials: "include", headers: headers(), body: JSON.stringify(body) }).then(function () {
      try {
        var st2 = readStore();
        if (st2) {
          if (kind === "post") (st2.posts || []).forEach(function (p) { if (String(p.id) === String(id)) p.body = next.slice(0, 4000); });
          else (st2.stories || []).forEach(function (s) { if (String(s.id) === String(id)) s.title = next.split("\n")[0].slice(0, 500); });
          localStorage.setItem(LS_KEY, JSON.stringify(st2));
        }
      } catch (e) {}
      toast("✏️ ویرایش ذخیره شد");
      setTimeout(refresh, 600);
    });
  }

  function userAction(action, userId, userName) {
    if (action === "ban" && !confirm("کاربر «" + userName + "» بن شود؟")) return;
    fetch("/api/admin?action=" + action, { method: "POST", credentials: "include", headers: headers(), body: JSON.stringify({ userId: userId }) }).then(function () {
      toast("✅ انجام شد");
      setTimeout(refresh, 600);
    });
  }

  // ---------- رندر ----------
  function ensureOverlay() {
    if (overlay) return overlay;
    overlay = document.createElement("div");
    overlay.id = "gamify-mod-overlay";
    overlay.className = "gamify-overlay";
    document.body.appendChild(overlay);
    return overlay;
  }
  function close() { if (overlay) overlay.classList.remove("open"); }
  function open() {
    if (!isAdmin) { toast("⚠️ فقط مدیر"); return; }
    ensureOverlay().classList.add("open");
    refresh();
  }

  function localPending() {
    var st = readStore();
    var lp = [], ls = [];
    if (st) {
      lp = (st.posts || []).filter(function (p) { return p && p.status === "pending"; }).map(function (p) {
        return { id: p.id, userName: p.author || "کاربر", body: p.body, category: p.category, createdAt: p.at, local: true };
      });
      ls = (st.stories || []).filter(function (s) { return s && s.status === "pending"; }).map(function (s) {
        return { id: s.id, userName: s.author || "کاربر", title: s.title, options: s.options, category: s.category, createdAt: s.at, local: true };
      });
    }
    // سرور را هم اضافه کن (تکراری‌ها را حذف کن)
    var srvP = state.posts.filter(function (p) { return !lp.some(function (x) { return String(x.id) === String(p.id); }); });
    var srvS = state.stories.filter(function (s) { return !ls.some(function (x) { return String(x.id) === String(s.id); }); });
    return { posts: lp.concat(srvP), stories: ls.concat(srvS) };
  }

  function postsHtml() {
    var all = localPending().posts;
    if (!all.length) return '<div class="gamify-empty">🎉 صف پست خالی است؛ همه‌چیز تأیید شده!</div>';
    return all.map(function (p) {
      return '<div class="gamify-mod-card"><div class="gamify-mod-head"><b>' + esc(p.userName || "کاربر") + "</b><span>" + (p.local ? "💾 محلی" : "☁️ سرور") + " · " + esc(p.category || "") + " · " + timeAgo(p.createdAt) + "</span></div>" +
        '<p class="gamify-mod-body">' + esc(p.body || "").slice(0, 600) + "</p>" +
        (p.media ? '<div style="font-size:12px;opacity:.7;">🖼 عکس دارد</div>' : "") +
        '<div class="gamify-row"><button class="gamify-btn sm primary" data-ok="post:' + esc(p.id) + '">✅ تأیید و انتشار</button><button class="gamify-btn sm" data-edit="post:' + esc(p.id) + '">✏️ ویرایش</button><button class="gamify-btn sm danger" data-no="post:' + esc(p.id) + '">🗑️ رد</button></div></div>';
    }).join("");
  }

  function storiesHtml() {
    var all = localPending().stories;
    if (!all.length) return '<div class="gamify-empty">🎉 صف استوری خالی است!</div>';
    return all.map(function (s) {
      var opts = (s.options || []).map(function (o, i) { return "<li>" + (i === s.correct ? "✅ " : "") + esc(o) + "</li>"; }).join("");
      return '<div class="gamify-mod-card"><div class="gamify-mod-head"><b>' + esc(s.userName || "کاربر") + "</b><span>" + (s.local ? "💾 محلی" : "☁️ سرور") + " · " + esc(s.category || "") + " · " + timeAgo(s.createdAt) + "</span></div>" +
        '<p class="gamify-mod-body"><b>❓ ' + esc(s.title || "") + "</b></p>" + (opts ? "<ol class='gamify-mod-opts'>" + opts + "</ol>" : "") +
        (s.explanation ? '<p style="font-size:12px;opacity:.8;">💡 ' + esc(s.explanation).slice(0, 300) + "</p>" : "") +
        '<div class="gamify-row"><button class="gamify-btn sm primary" data-ok="story:' + esc(s.id) + '">✅ تأیید و انتشار</button><button class="gamify-btn sm" data-edit="story:' + esc(s.id) + '">✏️ ویرایش</button><button class="gamify-btn sm danger" data-no="story:' + esc(s.id) + '">🗑️ رد</button></div></div>';
    }).join("");
  }

  function usersHtml() {
    if (!state.users.length) return '<div class="gamify-empty">کاربری در سرور ثبت نشده یا دسترسی نداری.<br><small>کاربران پس از ورود/همگام‌سازی اینجا دیده می‌شوند.</small></div>';
    var online = state.users.filter(function (u) { return u.online; }).length;
    return '<div class="gamify-mod-head" style="margin-bottom:10px;"><b>👥 ' + fa(state.users.length) + " کاربر</b><span>🟢 " + fa(online) + " آنلاین</span></div>" +
      state.users.slice(0, 80).map(function (u) {
        return '<div class="gamify-rank"><b>' + (u.online ? "🟢" : "⚪") + " " + esc(u.name) + (u.role === "admin" ? " 👑" : "") + '</b><span>⭐ ' + fa(u.xp) + " · 🏢 " + esc(u.orgId || "آزاد") + " · " + timeAgo(u.lastSeen) + "</span>" +
          '<span class="gamify-tribe-acts"><button class="gamify-btn sm" data-uadmin="' + esc(u.id) + '" data-name="' + esc(u.name) + '">👑 ادمین</button><button class="gamify-btn sm danger" data-uban="' + esc(u.id) + '" data-name="' + esc(u.name) + '">⛔ بن</button></span></div>';
      }).join("");
  }

  function overviewHtml() {
    if (!state.overview) return '<div class="gamify-empty">داده‌ای نیست.</div>';
    var s = state.overview.stats || {};
    var cards = [["👥 کاربران", s.totalUsers], ["🟢 آنلاین", s.onlineUsers], ["🛡️ قبیله‌ها", s.totalTribes], ["📝 پست منتظر", s.pendingPosts], ["📸 استوری منتظر", s.pendingStories], ["🏆 تورنمنت‌ها", s.totalTournaments], ["⚔️ نبرد فعال", s.activeBattles]]
      .map(function (c) { return '<div class="gamify-stat-card"><b>' + fa(c[1] || 0) + "</b><small>" + c[0] + "</small></div>"; }).join("");
    var recent = (state.overview.recentUsers || []).map(function (u) {
      return '<div class="gamify-rank"><b>' + (u.online ? "🟢" : "⚪") + " " + esc(u.name) + "</b><span>" + timeAgo(u.lastSeen) + "</span></div>";
    }).join("");
    return '<div class="gamify-stat-grid">' + cards + "</div><h3>🕒 آخرین بازدیدها</h3>" + (recent || "—") +
      '<p class="gamify-hint">🤖 اتوماسیون (ربات مدیر) سر جایش است؛ تأیید دستی تو فقط روی مواردی که می‌بینی اثر می‌گذارد و خللی در انتشار خودکار ایجاد نمی‌کند.</p>';
  }

  function render() {
    if (!overlay || !overlay.classList.contains("open")) return;
    var tabs = [["posts", "📝 پست‌ها"], ["stories", "📸 استوری‌ها"], ["users", "👥 کاربران"], ["overview", "📊 نمای کلی"]];
    var body = state.tab === "posts" ? postsHtml() : state.tab === "stories" ? storiesHtml() : state.tab === "users" ? usersHtml() : overviewHtml();
    overlay.innerHTML = '<div class="gamify-modal wide"><div class="gamify-modal-head"><b>📋 پنل زندهٔ مدیر</b><span><button class="gamify-btn sm" data-act="refresh">🔄 تازه‌سازی</button> <button data-act="close">✕</button></span></div>' +
      '<div class="gamify-tabs">' + tabs.map(function (t) { return '<button data-tab="' + t[0] + '" class="' + (state.tab === t[0] ? "active" : "") + '">' + t[1] + "</button>"; }).join("") + "</div>" +
      (state.loading ? '<div class="gamify-loading">' + esc(state.loading) + "</div>" : "") +
      '<div class="gamify-body">' + body + "</div>" +
      '<p class="gamify-hint">🟢 زنده: هر ۱۵ ثانیه خودکار تازه می‌شود · 💾 محلی = داخل مرورگر کاربر · ☁️ سرور = آینهٔ سرور</p></div>';
    overlay.querySelectorAll("[data-tab]").forEach(function (b) { b.addEventListener("click", function () { state.tab = b.getAttribute("data-tab"); refresh(); }); });
    overlay.querySelectorAll('[data-act="close"]').forEach(function (b) { b.addEventListener("click", close); });
    overlay.querySelectorAll('[data-act="refresh"]').forEach(function (b) { b.addEventListener("click", refresh); });
    overlay.querySelectorAll("[data-ok]").forEach(function (b) { b.addEventListener("click", function () { var p = b.getAttribute("data-ok").split(/:(.+)/); decide(p[0], p[1], "approved"); }); });
    overlay.querySelectorAll("[data-no]").forEach(function (b) { b.addEventListener("click", function () { var p = b.getAttribute("data-no").split(/:(.+)/); decide(p[0], p[1], "rejected"); }); });
    overlay.querySelectorAll("[data-edit]").forEach(function (b) { b.addEventListener("click", function () { var p = b.getAttribute("data-edit").split(/:(.+)/); editItem(p[0], p[1]); }); });
    overlay.querySelectorAll("[data-uban]").forEach(function (b) { b.addEventListener("click", function () { userAction("ban", b.getAttribute("data-uban"), b.getAttribute("data-name")); }); });
    overlay.querySelectorAll("[data-uadmin]").forEach(function (b) { b.addEventListener("click", function () { userAction("make-admin", b.getAttribute("data-uadmin"), b.getAttribute("data-name")); }); });
  }

  function mountFab() {
    if (document.getElementById("gamify-mod-fab")) return;
    var b = document.createElement("button");
    b.id = "gamify-mod-fab";
    b.textContent = "📋";
    b.title = "پنل زندهٔ مدیر";
    document.body.appendChild(b);
    b.addEventListener("click", open);
    updateBadge();
  }

  function boot() {
    checkAdmin();
    setInterval(checkAdmin, 8000);
    setInterval(updateBadge, 20000);
    setInterval(function () { if (overlay && overlay.classList.contains("open")) refresh(); }, 15000);
    document.addEventListener("click", function (e) { if (overlay && e.target === overlay) close(); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && overlay) close(); });
    console.log("%c[gamify] moderation فعال شد ✅", "color:#7cd7b6");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
