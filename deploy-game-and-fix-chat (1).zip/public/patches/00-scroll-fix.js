/* 🔧 فیکس قطعی پرش صفحه در چت (دستیار هوشمند + گفت‌وگوی بازیکنان)

   ریشهٔ واقعی باگ (در باندل اصلی):
   ۱) هر دو چت بعد از هر پیام «<div ref=…/>» انتهای لیست را با
      scrollIntoView({behavior:"smooth"}) صدا می‌زنند. این فراخوانی همهٔ اجداد اسکرول‌دار
      — از جمله خودِ صفحه — را حرکت می‌دهد.
   ۲) کادر پیام‌ها فقط کلاس‌های ابزاری «flex-1 space-y-2 overflow-y-auto» دارد و هیچ کلاسی
      با نام chat/message ندارد؛ پس تشخیص بر اساس نام کلاس اصلاً کار نمی‌کرد.
   ۳) پنل گفت‌وگوی بازیکنان «min-h-[70vh]» دارد (نه ارتفاع ثابت)؛ پس با هر پیام جدید
      خودِ صفحه بلندتر می‌شد و کادر هرگز اسکرول نمی‌شد (راه‌حل در patches.css).

   راه‌حل: scrollIntoView را سراسری بازنویسی می‌کنیم؛ فقط «نزدیک‌ترین کادر اسکرول‌دار»
   حرکت کند و هرگز خود صفحه نپرد. */
(function () {
  "use strict";
  if (window.__gamifyScrollFix2) return;
  window.__gamifyScrollFix2 = true;

  var origSIV = Element.prototype.scrollIntoView;
  var origFocus = HTMLElement.prototype.focus;
  var guardUntil = 0;
  var guardY = 0;
  var guardX = 0;
  var lastUserInput = 0;

  function isScrollable(el) {
    try {
      var s = window.getComputedStyle(el);
      var oy = s.overflowY;
      return oy === "auto" || oy === "scroll" || oy === "overlay";
    } catch (e) { return false; }
  }

  function scrollParentOf(el) {
    var p = el && el.parentElement;
    while (p && p !== document.body && p !== document.documentElement) {
      if (isScrollable(p)) return p;
      p = p.parentElement;
    }
    return null;
  }

  function isSentinel(el) {
    // عنصر خالیِ انتهای لیست پیام‌ها
    return !el.children.length && !(el.textContent || "").replace(/\s/g, "");
  }

  function armGuard() {
    guardUntil = Date.now() + 900;
    guardY = window.scrollY || window.pageYOffset || 0;
    guardX = window.scrollX || window.pageXOffset || 0;
  }

  Element.prototype.scrollIntoView = function (arg) {
    try {
      var behavior = arg && typeof arg === "object" && arg.behavior ? arg.behavior : "auto";
      var sentinel = isSentinel(this);
      var box = scrollParentOf(this);
      if (box) {
        armGuard();
        var top;
        if (sentinel) {
          top = box.scrollHeight;
        } else {
          var br = box.getBoundingClientRect();
          var er = this.getBoundingClientRect();
          var block = arg && typeof arg === "object" ? arg.block : "start";
          if (block === "end") top = box.scrollTop + (er.bottom - br.bottom);
          else if (block === "center") top = box.scrollTop + (er.top - br.top) - (box.clientHeight - er.height) / 2;
          else if (block === "nearest") {
            if (er.top < br.top) top = box.scrollTop + (er.top - br.top);
            else if (er.bottom > br.bottom) top = box.scrollTop + (er.bottom - br.bottom);
            else return;
          } else top = box.scrollTop + (er.top - br.top);
        }
        try { box.scrollTo({ top: top, behavior: behavior === "smooth" ? "smooth" : "auto" }); }
        catch (e) { box.scrollTop = top; }
        return; // هرگز صفحه را حرکت نده
      }
      if (sentinel) { armGuard(); return; }
    } catch (e) { /* به رفتار اصلی برگرد */ }
    return origSIV.apply(this, arguments);
  };

  // فوکوس کردن ورودی بلافاصله بعد از ارسال پیام نباید صفحه را بپراند
  HTMLElement.prototype.focus = function (opts) {
    try {
      if (Date.now() < guardUntil + 700) {
        var o = {};
        if (opts && typeof opts === "object") for (var k in opts) o[k] = opts[k];
        o.preventScroll = true;
        return origFocus.call(this, o);
      }
    } catch (e) { /* ignore */ }
    return origFocus.apply(this, arguments);
  };

  // نگهبان: اگر صفحه در بازهٔ کوتاه بعد از ارسال/اسکرول چت جابه‌جا شد (و کاربر خودش اسکرول نکرده)، برگردان
  function markUser() { lastUserInput = Date.now(); }
  ["wheel", "touchstart", "touchmove", "mousedown", "pointerdown"].forEach(function (ev) {
    window.addEventListener(ev, markUser, { passive: true, capture: true });
  });
  window.addEventListener("keydown", function (e) {
    if (e.key === "Enter") { armGuard(); return; }
    if (["ArrowUp", "ArrowDown", "PageUp", "PageDown", "Home", "End", " "].indexOf(e.key) !== -1) markUser();
  }, true);
  window.addEventListener("submit", armGuard, true);
  window.addEventListener("click", function (e) {
    try {
      var b = e.target && e.target.closest ? e.target.closest("button") : null;
      if (b && b.closest("form, .gm-panel, .fixed")) armGuard();
    } catch (err) { /* ignore */ }
  }, true);

  window.addEventListener("scroll", function () {
    if (Date.now() >= guardUntil) return;
    if (Date.now() - lastUserInput < 350) return;
    var y = window.scrollY || window.pageYOffset || 0;
    var x = window.scrollX || window.pageXOffset || 0;
    if (Math.abs(y - guardY) > 2 || Math.abs(x - guardX) > 2) {
      try { window.scrollTo({ top: guardY, left: guardX, behavior: "auto" }); }
      catch (e) { window.scrollTo(guardX, guardY); }
    }
  }, { passive: true });

  // CSS کمکی: لنگر اسکرول و زنجیرهٔ اسکرول داخل کادر پیام‌ها خاموش
  function injectCss() {
    if (document.getElementById("gamify-scroll-fix-css")) return;
    var st = document.createElement("style");
    st.id = "gamify-scroll-fix-css";
    st.textContent =
      '[class*="overflow-y-auto"][class*="space-y-2"]{overscroll-behavior:contain;overflow-anchor:none;scroll-behavior:auto}' +
      'textarea,input{scroll-margin:0}';
    (document.head || document.documentElement).appendChild(st);
  }
  if (document.head) injectCss();
  else document.addEventListener("DOMContentLoaded", injectCss);
})();
