/* 🌍 امکانات درجه‌جهانی: پاداش روزانه، دستاوردها، جشن، ذرات شناور، حضور آنلاین */
(function () {
  "use strict";
  if (window.__gamifyWorld) return;
  window.__gamifyWorld = true;

  var LS_KEY = "gamify2-store-v2";
  var META_KEY = "gamify2-server";
  var reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function readStore() { try { return JSON.parse(localStorage.getItem(LS_KEY) || "null"); } catch (e) { return null; } }
  function readMeta() { try { return JSON.parse(localStorage.getItem(META_KEY) || "{}"); } catch (e) { return {}; } }
  function writeMeta(m) { try { localStorage.setItem(META_KEY, JSON.stringify(m)); } catch (e) {} }
  function esc(s) { return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function fa(n) { try { return Number(n || 0).toLocaleString("fa-IR"); } catch (e) { return String(n || 0); } }

  // ---------- تост عمومی ----------
  window.__gamifyToast = function (msg) {
    var d = document.createElement("div");
    d.className = "gamify-toast-in";
    d.textContent = msg;
    d.style.cssText = "position:fixed;bottom:86px;right:16px;z-index:100999;background:#241a33;color:#fff;padding:10px 16px;border-radius:14px;font-size:13px;box-shadow:0 8px 30px rgba(0,0,0,.4);border:1px solid #f2ca7c;font-family:Vazirmatn,sans-serif;max-width:min(92vw,400px);animation:gamifyToastIn .35s ease;";
    document.body.appendChild(d);
    setTimeout(function () { d.style.transition = "opacity .4s"; d.style.opacity = "0"; setTimeout(function(){ d.remove(); }, 450); }, 3000);
  };

  // ---------- کانفتی سبک ----------
  window.__gamifyConfetti = function () {
    if (reduced) return;
    try {
      var c = document.createElement("canvas");
      c.style.cssText = "position:fixed;inset:0;z-index:100998;pointer-events:none;";
      c.width = innerWidth; c.height = innerHeight;
      document.body.appendChild(c);
      var ctx = c.getContext("2d");
      var colors = ["#f2ca7c", "#a98cf7", "#7cd7b6", "#eda0b9", "#76bfec", "#fff"];
      var parts = [];
      for (var i = 0; i < 130; i++) {
        parts.push({ x: innerWidth / 2 + (Math.random() - 0.5) * 200, y: innerHeight * 0.35, vx: (Math.random() - 0.5) * 14, vy: Math.random() * -12 - 3, w: 5 + Math.random() * 7, h: 8 + Math.random() * 8, r: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 0.3, c: colors[i % colors.length], life: 1 });
      }
      var frames = 0;
      (function tick() {
        frames++;
        ctx.clearRect(0, 0, c.width, c.height);
        var alive = false;
        parts.forEach(function (p) {
          p.vy += 0.35; p.x += p.vx; p.y += p.vy; p.r += p.vr; p.life -= 0.008;
          if (p.life > 0 && p.y < innerHeight + 30) alive = true;
          ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.globalAlpha = Math.max(0, p.life);
          ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); ctx.restore();
        });
        if (alive && frames < 300) requestAnimationFrame(tick);
        else c.remove();
      })();
    } catch (e) {}
  };

  // ---------- ذرات شناور پس‌زمینه (خانه) ----------
  function mountParticles() {
    if (reduced || document.getElementById("gamify-particles")) return;
    var c = document.createElement("canvas");
    c.id = "gamify-particles";
    c.style.cssText = "position:fixed;inset:0;z-index:0;pointer-events:none;opacity:.5;";
    document.body.appendChild(c);
    var ctx = c.getContext("2d");
    var dots = [];
    function size() { c.width = innerWidth; c.height = innerHeight; }
    size();
    window.addEventListener("resize", size);
    for (var i = 0; i < 40; i++) dots.push({ x: Math.random(), y: Math.random(), r: 1 + Math.random() * 2.5, s: 0.0002 + Math.random() * 0.0008, o: 0.15 + Math.random() * 0.5, hue: [45, 265, 160, 340][i % 4] });
    (function tick() {
      if (!document.body.contains(c)) return;
      // فقط در خانه و تالار نمایش بده تا حواس پرت نشود
      var h = location.hash || "#home";
      c.style.opacity = (h === "#home" || h === "" || h.indexOf("#leaderboard") === 0) ? ".5" : "0";
      ctx.clearRect(0, 0, c.width, c.height);
      dots.forEach(function (d) {
        d.y -= d.s;
        if (d.y < -0.02) { d.y = 1.02; d.x = Math.random(); }
        ctx.beginPath();
        ctx.arc(d.x * c.width, d.y * c.height, d.r, 0, 7);
        ctx.fillStyle = "hsla(" + d.hue + ",80%,70%," + d.o + ")";
        ctx.fill();
      });
      requestAnimationFrame(tick);
    })();
    // روت را بالاتر ببر تا ذرات زیر محتوا باشند
    try {
      var root = document.getElementById("root");
      if (root) { root.style.position = "relative"; root.style.zIndex = "1"; }
    } catch (e) {}
  }

  // ---------- پاداش روزانه ----------
  function checkDaily() {
    var st = readStore();
    if (!st || !st.profile) return;
    var meta = readMeta();
    var today = new Date().toISOString().slice(0, 10);
    if (meta.dailyShown === today) return;
    fetch("/api/daily", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (j) {
      if (!j || j.error || j.claimed) return;
      meta.dailyShown = today; writeMeta(meta);
      showDailyModal(j.streak || 0);
    }).catch(function () {});
  }
  function showDailyModal(streak) {
    var ov = document.createElement("div");
    ov.className = "gamify-overlay open";
    ov.style.zIndex = "100997";
    ov.innerHTML = '<div class="gamify-modal" style="text-align:center;max-width:380px;">' +
      '<div style="font-size:64px;animation:gamifyFloat 2.4s ease-in-out infinite;">🎁</div>' +
      "<h2>جایزهٔ روزانه‌ات آماده است!</h2>" +
      "<p class='gamify-hint'>🔥 استریک فعلی: " + fa(streak) + " روز · هر روز برگرد تا جایزه بزرگ‌تر شود!</p>" +
      '<div class="gamify-row" style="justify-content:center;"><button class="gamify-btn primary" data-claim>🎁 دریافت جایزه</button><button class="gamify-btn" data-later>بعداً</button></div></div>';
    document.body.appendChild(ov);
    ov.querySelector("[data-later]").addEventListener("click", function () { ov.remove(); });
    ov.querySelector("[data-claim]").addEventListener("click", function () {
      fetch("/api/daily", { method: "POST", credentials: "include" }).then(function (r) { return r.json(); }).then(function (j) {
        if (j && j.ok) {
          try {
            var st = readStore();
            if (st && st.profile) {
              st.profile.coins = (st.profile.coins || 0) + j.coins;
              st.profile.streak = j.streak;
              st.profile.xp = (st.profile.xp || 0) + 20;
              localStorage.setItem(LS_KEY, JSON.stringify(st));
            }
          } catch (e) {}
          ov.querySelector(".gamify-modal").innerHTML = '<div style="font-size:64px;">🎉</div><h2>+' + fa(j.coins) + " سکه!</h2><p class='gamify-hint'>" + esc(j.message || "") + "</p>";
          window.__gamifyConfetti();
          setTimeout(function () { ov.remove(); }, 2500);
        } else {
          window.__gamifyToast("⚠️ " + ((j && j.error) || "خطا"));
          ov.remove();
        }
      }).catch(function () { ov.remove(); });
    });
  }

  // ---------- دستاوردها ----------
  var seenAch = {};
  try { seenAch = readMeta().seenAch || {}; } catch (e) {}
  function checkAchievements() {
    var st = readStore();
    if (!st || !st.profile) return;
    fetch("/api/daily?kind=achievements", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
      if (!Array.isArray(rows)) return;
      rows.filter(function (a) { return a.unlocked && !seenAch[a.id]; }).slice(0, 2).forEach(function (a, i) {
        seenAch[a.id] = 1;
        setTimeout(function () {
          window.__gamifyToast("🏅 دستاورد: " + a.title + " (+" + fa(a.coinReward) + " سکه)");
          window.__gamifyConfetti();
        }, i * 1500);
      });
      var m = readMeta(); m.seenAch = seenAch; writeMeta(m);
    }).catch(function () {});
  }

  // ---------- جشن ارتقای سطح ----------
  var lastLevel = 0;
  function watchLevel() {
    try {
      var st = readStore();
      if (!st || !st.profile) return;
      var lvl = Math.floor((st.profile.xp || 0) / 250) + 1;
      if (lastLevel && lvl > lastLevel) {
        window.__gamifyToast("🚀 سطح " + fa(lvl) + " شدی! آفرین قهرمان!");
        window.__gamifyConfetti();
      }
      lastLevel = lvl;
    } catch (e) {}
  }

  // ---------- شمارش آنلاین در هدر ----------
  function injectOnlineBadge() {
    try {
      if (document.getElementById("gamify-online-badge")) return;
      // دنبال جایگاه مناسب در هدر: کنار سکه/کاربر
      var anchors = Array.from(document.querySelectorAll("header a, header button, header span")).filter(function (el) {
        return /سکه|coin|🪙/i.test(el.textContent || "") || (el.textContent || "").length < 3;
      });
      var host = anchors[0] ? anchors[0].parentElement : document.querySelector("header");
      if (!host) return;
      var b = document.createElement("span");
      b.id = "gamify-online-badge";
      b.style.cssText = "font-size:11px;background:rgba(124,215,182,.12);border:1px solid rgba(124,215,182,.5);color:#7cd7b6;border-radius:999px;padding:3px 10px;margin:0 6px;white-space:nowrap;font-family:Vazirmatn,sans-serif;";
      b.textContent = "🟢 …";
      host.appendChild(b);
      updateOnlineBadge();
    } catch (e) {}
  }
  function updateOnlineBadge() {
    var b = document.getElementById("gamify-online-badge");
    if (!b) return;
    fetch("/api/players?online=1&limit=200", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (rows) {
      if (Array.isArray(rows)) b.textContent = "🟢 " + fa(rows.length) + " آنلاین واقعی";
    }).catch(function () {});
  }

  // ---------- دکمهٔ هدیه شناور ----------
  function mountGiftFab() {
    if (document.getElementById("gamify-gift-fab")) return;
    var b = document.createElement("button");
    b.id = "gamify-gift-fab";
    b.textContent = "🎁";
    b.title = "جایزهٔ روزانه";
    document.body.appendChild(b);
    b.addEventListener("click", function () {
      fetch("/api/daily", { credentials: "include" }).then(function (r) { return r.json(); }).then(function (j) {
        if (j && !j.error && !j.claimed) showDailyModal(j.streak || 0);
        else if (j && j.claimed) window.__gamifyToast("✅ جایزهٔ امروز را گرفتی! فردا برگرد 🎁");
        else window.__gamifyToast("🌱 اول وارد بازی شو!");
      }).catch(function () {});
    });
  }

  // ---------- لرزش (هپتیک) روی جواب ----------
  document.addEventListener("click", function (e) {
    try {
      var t = e.target && e.target.closest ? e.target.closest(".gamify-opt, [data-opt], [data-story-choice]") : null;
      if (t && navigator.vibrate) navigator.vibrate(15);
    } catch (err) {}
  }, true);

  function boot() {
    setTimeout(mountParticles, 2000);
    setTimeout(mountGiftFab, 4500);
    setTimeout(injectOnlineBadge, 6000);
    setInterval(injectOnlineBadge, 15000);
    setInterval(updateOnlineBadge, 60000);
    setTimeout(checkDaily, 8000);
    setTimeout(checkAchievements, 10000);
    setInterval(checkAchievements, 120000);
    setInterval(watchLevel, 4000);
    // خوش‌آمد گویی هوشمند
    setTimeout(function () {
      try {
        var st = readStore();
        var m = readMeta();
        if (st && st.profile && !m.welcomed) {
          m.welcomed = 1; writeMeta(m);
          if (!st.profile.org) window.__gamifyToast("👋 خوش آمدی " + (st.profile.name || "") + "! دکمهٔ 🏢 را بزن اگر عضو سازمانی هستی.");
        }
      } catch (e) {}
    }, 15000);
    console.log("%c[gamify] worldclass فعال شد ✅", "color:#f2ca7c");
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
